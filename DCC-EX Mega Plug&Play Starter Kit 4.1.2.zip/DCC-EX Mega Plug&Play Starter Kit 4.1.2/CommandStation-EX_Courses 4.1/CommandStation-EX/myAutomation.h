 /*  
 *****************************************************************************************************************
 * This is a "myAutomation_Courses.h"  Example EXRAIL Automation sample file.                    August 22, 2022
 *  Designed to run on a Mega DCC-EX v4.1 EXRAIL Command Station
 *****************************************************************************************************************
 *************** By Kevin C Smith, DCC-EX Dev Team and a SCMRRC member *******************************************
 *  This sample myAutomation.h file requires DCC++EX EXRAIL 4.1.2 or higher
 *
 *  It is designed to run with the example layout in the 'Sample EXRAIL Automation' Station A to Station B.
 *    Which Includes many sample
 *    Sensors, Servo Turnouts, LED Point Signals, WiThrottle App Commands and additional
 *    Special Effect FX macros
 *     FX Railfan Walking
 *     FX Arc Welder
 *     FX Campfire
 *     FX Caution Signals
 *     FX DFPlayer mini micro-SD MP3 sound card
 *     FX Ultra Sonic Sensor & Lighting/Sound effect
 *
 *    and runs many EXRAIL Automation, Route & Sequences from Station A to Station B on Two Tracks A & B.
 *
 *    It Requires you to #include these three EXRAIL Lessons & DCC-EX Commands Summary futher down
 *      Lessons: (101 thru 107)   Setup Command Station Startup & Layout Accessories
 *      Lessons: (201,thru 205)   Control Automation & Trains with Engine Driver & WiThrottle Apps
 *      DCCEX_CommandSummary      Bonus DCC-EX Command Summary Lists on IDE Serial Monitor Display
 *    
 *****************************************************************************************************************
 * Acknowledgement; DCC-EX Created by Chris Harlow, Harald Barth, Neil McKechnie, Fred Decker & DCC-EX Dev Team
 *****************************************************************************************************************
 *  The presence of a file called "myAutomation.h" brings EX-RAIL code into the command station.
 *  The automation may have multiple concurrent tasks. 
 *  A task may
 *  - Act as a ROUTE setup macro for a user to drive over
 *  - drive a loco through an AUTOMATION
 *  - automate some cosmetic part of the layout without any loco.
 * 
 *  At startup, a single task is created to execute the first 
 *  instruction after EXRAIL.
 *  This task may simply follow a route, or may START
 *  further tasks (thats is.. send a loco out along a route).
 *
 *  Where the loco id is not known at compile time, a new task 
 *  can be created with the command:
 *  </ START [cab] route>
 *  
 * EXRAIL Sample
 * Macros for Rosters, Servo Turnouts & Signals, Special Accessory Servo movement & Special Lighting Effects.  
 * And Train Control AUTOMATION(n), ROUTE(n) & SEQUENCE(n) Scripts
 *
 *  A AUTOMATION, Route or SEQUENCE are internally identical in EX-Rail terms  
 *  but are just represented differently to a WiThrottle user:
 *  ROUTE(n,"name") - as Route_n .. to setup a route through a layout
 *  AUTOMATION(n,"name") as Auto_n .. to send the current loco off along an automated journey
 *  SEQUENCE(n) is not visible to WiThrottle.
 ******************************************************************************************************************
 */

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Note; Command Station Setup,
//  This file Assumes you've have already built a Working Mega + WiFI Command Station with the following;
//  DCC-EX Command Station V4.1.2 Master or greater.
//  Arduino Mega 2560 micro controller or clone equivalent with a 7-9Vdc center positive power supply
//  a USB A to B cable for Firmware upgrades
//  Arduino or DeekRobot L298P Motor Shield {vin cut} with a 12-16Vdc center positive power supply
//  Makerfab WiFi ESP8266 Shield or ESP01 board or ESP 8266 WiFi compatible device
//  Accessories;
//   Four Infrared Sensors Sns22, Sns23, Sns24, & Sns25 in Mega Dpins 22,23,24 & 25
//   One PCA9685 Servo/Signal board wired from {SCL, SDA, VCC, Gnd} to the Motor Shield {SCL, SDA, 5V, Gnd} Male pins
//   Three 9gram Servo Turnouts connected on PCA9685 Vpins 101, 102, & 105 with three pin connector on Output, 5v, Gnd
//   Red\Green LEDs Point Signals connected on PCA9685 Vpins Red 106 & 108, and Green 107 & 109 with two pins Output & Gnd
//   One White, One Blue LEDs 'FX Arc Welder' on PCA9685 Vpins 112 & 113 with two pins Output & Gnd
//   One Red or Yellow LED 'FX Campfire' on PCA9685 Vpins 114 with two pins Output & Gnd
//   Two Red or Yellow LEDs 'FX Caution or Crossing Signal' on the PCA9685 Vpin 114 & 115 on pins Output & Gnd
// Adjust the Servo Angles to fit your Point throw distances separately before using them in this script.
//
// Bonus Accessories Setup in myHal.cpp
//   One DFPlayer mini MP3 Micro-SD Sound Card setup on Serial l Tx1 Rx1 {D18, D19} and 15 sound files on Vpins 1500-1514
//   One HCSR04 Ultrasonic Sensor setup as Vpin2000 and with Mega pins D40=TRIG , D41=ECHO
//     
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
// Please be sure your DCC-EX Command Station and your WiFi Throttles are connected to the same local WiFi name      ||
// Your WiFi Router Station STA mode to SSID 'Name' & 'Password'                                                     ||
//  Or in this DCCEX Command Stations direct Access Point AP mode to DCCEX_"xxxxxx" & PASS_"xxxxxx"                  ||
//  See your config.h and edit the WiFi settings as needed                                                           ||
//|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 //  You can include many sample Setup Command Station Startup, Layout & Automations lessons below
 //      Lessons: (101 thru 107)  Setup Command Station Startup & Layout Accessories
 //      Lessons: (201,thru 205)  Control Automation & Trains with Engine Driver & WiThrottle Apps
 //
 //  NOTE; Be carefull not to accidentally overwrite your personal myAutomation.h file & mySetup.h & other myfiles.
 //  You can temporaraly rename yours to a unique name like myAutomation_Initials.h and mySetup_Initials.h
 //  Then Copy & Rename this "myAutomation_Course.h" file to myAutomation.h" file
 //    And Temporaraly use this files INSTEAD of your unique personnel "my___.h" files
 //
 //  Later you can copy & paste any desired samples from These  myEXRAIL_Courses_Macros.h to your file as needed.
 //   Then just Recompile & Upload to your Mega + WiFi Command Station
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// ******************************************************************************************************************* //
 // The following sample my.h files can be included and used inside your user defined "myAutomation.h" file
 // They must be copied to and present inside your CommandStation-EX Folder first before they can be used.
 // These must have a DONE at the end of a list of startup macros or the scripts Below them will automatically start.
// ******************************************************************************************************************* //
// ******************************************************************************************************************* //
 // Optionally Include and call additional "myEXRAIL_.h" setup scripts into your "myAutomation.h" file
      #include "myEXRAIL_Courses_100_Macros.h"   // Lessons 100 Setup Command Station Startup & Layout Accessories
      #include "myEXRAIL_Courses_200_Macros.h"   // Lessons 200 Setup Control Automation & Trains with Engine Driver     
      #include "myDCCEX_CommandSummary4.1.h"     // Bonus DCC-EX Command Summary Lists on IDE Serial Monitor Display
 // Your #include "myEXRAIL_something.h"         // Your optional individual myEXRAIL_.h files
// ******************************************************************************************************************* //

// ******************************************************************************************************************** //
// Optional, Add Your Practice Roster List;                                                         -- Conductor Level
// Copy & place your unique uncommented Roster List here from your edited sample in "myEXRAIL_Courses_100_Macros.h file.
// ******************************************************************************************************************** //
//  Create DCC Engine Rosters for decoders With & Without Sound
//   {Name Syntax Caps and spaces matter If you want to syncronize with the JMRI Roster}
//     Use *asterisk for function keys that are unlatched i.e. Horn & Whistle
//
//  Example Defined Engine ROSTER(dcc_address,"name","F0/F1/*F2/*F3/F4/F5/F6/F7/Mute/etc/")
  // ROSTER(1225,"PE1225","Lights/Bell/*Whistle/*Short Whistle/Steam/On-Time/FX6 Bell Whistle/Dim Light/Mute")
  // ROSTER(1224,"PE1224","HeadLgt/") // a DCC Motor Only Decoder
  //
// ********************************************************************************************************************* //
// Auto Start Used on Holiday displays or for public exhibits
// To Automatically Start an Engine on a Automation(n) or Route(n) upon the Command Station bootup, Uncomment the next line
  //AUTOSTART SENDLOCO(1225,202) // Send Loco 1225 on AUTOMATION(202) Engine Roundhouse to Turntable Back & Forth - Timed
  
  DONE // This First DONE ends the myAutomation.h startup thread which Loads any Uncommented lines
       // above and Starts the Command Station with the track Power OFF
       // Unless you Start Automation and it Includes a POWERON command, then that Automation will Begin at Startup
       
 /*
 EXRAIL
   See the Tab myEXRAIL_Courses_100_Macros.h  // Lessons 100 Setup Command Station Startup & Layout Accessories
   See the Tab myEXRAIL_Courses_200_Macros.h  // Lessons 200 Setup Control Automation & Trains with Engine Driver 
   See the Tab myDCCEX_CommandSummary4.1.h    // Bonus DCC-EX Command Summary Lists on IDE Serial Monitor Display
 ENDEXRAIL
 */
