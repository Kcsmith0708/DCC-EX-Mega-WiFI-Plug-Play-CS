/*
 ***********************************************************************************************************************
 * This is "myEXRAIL_Courses_200_Macros.h" Control Automation & Trains with Engine Driver & WiThrottles  August 22, 2022
 *  Designed to run on a Mega DCC-EX v4.1.2+  Mega DCC-EX EXRAIL Command Station
 ***********************************************************************************************************************
 ********************* By Kevin C Smith, DCC++EX Dev Team and a SCMRRC member  *****************************************
 * 
 *  This myEXRAIL_Courses_200_Macros.h automation file requires DCC++EX 4.1.2 release or higher
 *   and can be used by renaming your current myAutomation.h file to something else like myAutomation_Initials.h
 *     then simple copy & rename myAutomation_Courses.h to myAutomation.h and it already includes this 
 *       #include "myEXRAIL_Courses_200_Macros.h"
 *       
 *   Then Recompile and uploade to a Mega + WiFi Command Station with a PCA9685 Servo Signal board & 9G Servos
 *    to Automatically run these Macros & Automation Scripts
 *      
 *   It is designed to run with a example layout 'Intro to EXRAIL Automation' Station A to Station B 
 *     Which Includes many Accesories samples;
 *       Two Servo_Turnouts with Red/Green LED point signals, a Animated Accessory Servo & Special FX Effects for; 
 *        Railfan Walking, FX ArcWelder, FX Campfire, FX Caution Signals & Lighting, DFPlayer MP3 Sound card,
 *       and runs many EXRAIL Automation, Route & Sequences from Station A to Station B on two tracks A & B.
 *    
 *    Note; Command Station Setup.
 *    Assumes a working DCC-EX MEGA + WiFi ready Command Station configuration,{NOT a UNO Command Station}
 *    DCC-EX Command Station V4.1.2 Master or greater.
 *    Arduino Mega 2560 micro controller or clone equivalent with a 7-9Vdc center positve power supply
 *    Arduino or Deek Robot L298P Motor Shield with {Vin Cut} and a 12-16Vdc center positive power supply 
 *    MakerFab ESP8266 Or a ESP01 board with ESP8266 WiFi compatable device
 *    Accessories;
 *     Four Infrared Sensors Sns22, Sns23, Sns24, & Sns25 in Mega Dpins 22,23,24 & 25
 *     One PCA9685 Servo/Signal board wired from {SCL, SDA, VCC, Gnd} to the Motor Shield {SCL, SDA, 5V, Gnd} Male pins
 *     Three 9gram Servo Turnouts connected on PCA9685 Vpins 101, 102, & 105 with three pin connector on Output, 5v, Gnd
 *     Red\Green LEDs Point Signals connected on PCA9685 Vpins Red 106 & 108, and Green 107 & 109 with two pins Output & Gnd
 *     One White, One Blue LEDs 'FX Arc Welder' on PCA9685 Vpins 112 & 113 with two pins Output & Gnd
 *     One Red or Yellow LED 'FX Campfire' on PCA9685 Vpins 114 with two pins Output & Gnd
 *     Two Red or Yellow LEDs 'FX Caution or Crossing Signal' on the PCA9685 Vpin 114 & 115 on pins Output & Gnd
 *   Adjust the Servo Angles to fit your Point throw distances separately before using them in this script.
 *    
 *    Bonus Accessories Setup in myHal.cpp
 *     One DFPlayer mini MP3 Micro-SD Sound Card setup on Serial l Tx1 Rx1 {D18, D19} and 15 sound files on Vpins 1500-1514
 *     One HCSR04 Ultrasonic Sensor setup as Vpin2000 and with Mega pins D40=TRIG , D41=ECHO
 *
 *************************************************************************************************************************  
 * Acknowledgement; DCC-EX Software Created by Chris Harlow, Harald Barth, Neil McKechnie, Fred Decker & DCC-EX Dev Team 
 *************************************************************************************************************************
 *  The presence of a file called "myAutomation.h" brings EX-RAIL code into the command station.
 *  The automation may have multiple concurrent setup procedures and tasks. 
 *  A task may be
 *  
 * EXRAIL Sample
 * Macros for Rosters, Alias, Servo Turnouts & Signals, Special Accessory Servo movement & Special FX Lighting Effects.   
 * And Train Control AUTOMATION(n), ROUTE(n) & SEQUENCE(n) Scripts
 *
 *  A AUTOMATION, Route or SEQUENCE are internally identical in EX-Rail terms  
 *  but are just represented differently to a WiThrottle user:
 *  ROUTE(n,"name") - as Route_n .. to setup a route through a layout
 *  AUTOMATION(n,"name") as Auto_n .. to send the current loco off along an automated journey
 *  SEQUENCE(n) is not visible to WiThrottle.
 */
 
//|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
// Please be sure your DCC-EX Command Station and your WiFi Throttles are connected to the same local WiFi name      ||
// Your WiFi Router Station STA mode to SSID 'Name' & 'Password'                                                     ||
//  Or in this DCCEX Command Stations direct Access Point AP mode to DCCEX_"xxxxxx" & PASS_"xxxxxx"                  ||
//  See your config.h and edit the WiFi settings as needed                                                           ||
//|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

// The following sample Commands & Scripts can be used in your user defined "myAutomation.h" file
// They must be copied to and present inside your CommandStation-EX Folder first before they can be used.
// These must have a DONE at the end of a list of startup macros or the scripts Below them will automatically start.
//********************************************************************************************************************* //
 // This EXRAIL Course Levels 200 in "myEXRAIL_Courses_200_Macros.h" version 4.1
 //      includes Lessons 201-205 Control Automation & Trains with Engine Driver & WiThrottle Apps.
 // For Additional Lessons 100-106 Setup Command Station Startup & Layout Accessories see "myEXRAIL_Courses_100_Macros.h"
//********************************************************************************************************************* //
//*************************************************************************************************************** //
// Optionally Include and call additional "myEXRAIL_.h" setup scripts into your main myAutomation.h file
   // #include "myDCCEX_CommandSummary.h"    // Bonus DCC-EX Command Summary Lists on IDE Serial Monitor Display
//*************************************************************************************************************** //

// Lets begin with EXRAIL Courses Lessons 201 - 205 Control Automation of Trains via Throttle {Handoff} & {Set} buttons
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 // Lesson Autostart  200 on a Automation(n) run.  {An example Lesson and line is already in you myAutomation.h file}
 // Lesson Automation 201 Prog Track Test Sound Engine Back & Forth
 // Lesson Automation 202 Engine from Roundhouse to Turntable Back & Forth - Timed
 // Lesson Automation 203 Engine from Station A to Station B - 2 Sensors Back & Forth Trolley
 // Lesson Automation 204 Engine from Station A to Station B - 2 Sensors & 2 Turnouts Multi Tracks Back & Forth
 // Lesson Automation 205 Engine from Station A to Station B - 3 Sensors & 2 Turnouts 1 Accessory Servo5 & DFPlayer MP3
 //*Lesson Automation 206 DC CAB from Station B to Station A - 3 Sensors & 2 Turnouts 1 Accessory Servo5 & DFPlayer MP3
//  * DC CAB capability is still in Development & Testing v5.0
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// ******************************************** \       _
//  Yeah! - Now it's time to Run Trains!!!        >    |_|__%
// ******************************************** /   ===O====O \===========================

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Lets begin with EXRAIL Courses Automation Lessons 201 - 205 Creating AUTOMATION & ROUTES for DCC Engines
// And control them Through Engine Driver and WiThrottle WiFi throttle Apps.

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Beginning any Automation, Route, Sequence & Macro Scripts command is optonal for DCC-EX v4.1
//
// You can start these from a IDE Serial Monitor with a command </START 201> or </START 1225 205> and from JMRI Send DCC++ Command 
// Or automatically from within myAutomation.h with SENDLOCO(1225,205) send loco 1225 along Automation 205
//
// And from a Engine Driver & WiThrottle by pressing EXRAIL 201 'Eng# Sound Prog Test' {Handoff} OR a Route {Set} button.
// A AUTOMATION(n) will take the last Loco# you touched or used in the throttle and send it on that script run.
// A ROUTE(n) will Throw & Close Turnouts or turn on FX Special Effects and let you drive Locos Manually .
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// *********************************************************************************************************************** //
// Lesson Automation 200  Start an Automation(n) at the Command Station bootup                        -- Conductor Level
// Use on Holiday displays or for Public exhibits
// To Automatically Run one You must Copy one or more of these lines placed in the myAutomation.h file 
//    Before the first DONE
// An example lesson and line is already in the myAutomation.h file
// *********************************************************************************************************************** //
// In my Automation.h You can change the first loco# to your Locos DCC Addrees and Uncomment it to run your engine.
  //AUTOSTART SENDLOCO(1225, 202) // send loco 1225 on AUTOMATION(202) EXRAIL 202 Roundhouse to Turntable Back & Forth - Timed
  //AUTOSTART SENDLOCO(1225, 203) // send loco 1225 on AUTOMATION(203) EXRAIL 203 Station A to B Sensors
  //AUTOSTART SENDLOCO(1225, 204) // send loco 1225 on AUTOMATION(204) EXRAIL 204 Station A to B Sensors & Turnouts
  //AUTOSTART SENDLOCO(1225, 205) // send loco 1225 on AUTOMATION(205) EXRAIL 205 Station A & Station B - Water Tower +MP3
  //AUTOSTART SENDLOCO(3, 206)    // send loco 3    on AUTOMATION(206) EXRAIL 206 TM DCdistrict CAB Back & Forth
  
  DONE // This First DONE ends the myAutomation.h startup thread which Loads any Uncommented lines
       // above and Starts the Command Station with the track Power OFF
       // Unless you Start Automation and it Includes a POWERON command, then that Automation will Begin at Startup
       
//     OR  Leave Them All Commented Out and then 

// From Engine Driver {Handoff} & WiThrottle {Route} buttons
// Select and Load a Loco into Engine Driver Throttle then swipe the screen to Routes screen and press a Automation(n)
//  A204 'EXRAIL 204 Station A to B Sensors & Turnouts' {Handoff} button
//  and the Engine in your Throttle will be sent on that Automation.
// IF the Automation is a Looping macro, Press the same {Handoff} button a 2nd time and the Automation completes it cycle & Ends.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// ********************************************************************************************************************** //
EXRAIL // Sample EXRAIL Automation Lessons 201 - 205 Creating AUTOMATION & ROUTES for DCC Engines
// ********************************************************************************************************************** //

// ********************************************************************************************************************** //
// Lesson Automation 201 Prog Track Test Sound Engine Back & Forth                                   -- Conductor Level
// ********************************************************************************************************************** //
/* AUTOMATION(201) is a DCC Sound decoder Engine test on the insulated Programming track
 *  from IDE Serial monitor enter </START 201> or
 *   from an Engine Driver throttle screen swipe left and press the 
 *     "EXRAIL 201 Sound Prog Test" {Handoff} button
 *  After it finishes its test Select the engine and Throttle Up and 'Drive Away' onto your insulated Main line track
 *   or Replace the engine and test another one.
 *                     
 *  >= START->================< then =======> 'Drive Away'
 *  
 *  Wire Motor Shield track B to a Programming Track or insulated Spur. 
 *  Place a DCC ready loco on the PROG track
*/
   AUTOMATION(201,"EXRAIL 201 Eng# Sound PROG Test")
    PRINT ("You've Started a Automation 201 Prog Test of a DCC Engine Back & Forth")
    POWERON      // Power up both tracks
    UNJOIN       // If Joined then UNJOIN Prog from the Main track
    DELAY(250)
    PRINT ("Reading this Engine# and sending it Back & Forth with Sound")
    READ_LOCO    // Start by Reading <R> a New Locomotive ID
    DELAY(2500)  // wait 2.5 seconds
    JOIN         // JOIN Prog to Main track
    DELAY(500)
    FWD(0)       // Set to Forward
    FON(0)       // F0 Headlight On
    PRINT ("Short F2 Whistle or Horn immediately to Acknowledge Acquired")
    FON(2)       // F2 Sound Horn
    DELAY(250)   // wait .25 sec Short Whistle/Horn 
    FOFF(2)      // Horn Off
    PRINT("")     PRINT ("Startup Blow Horn, Run Forward speed 25 for 4 seconds STOP and Return")
    PRINT ("Test Multiple Function Key Sounds and Special Effects")
     // Add more FON(n) and FOFF(n) as desired
    FOFF(3)DELAY(200)FON(3) // Set MTH Decoder Function F3 Engine Start Up Proceedures
                            // Or a F3 as a Short Whistle or Coupler on other decoders
    DELAY(250)
    FON(9)       // Set QSI Paragon3 decoder F9 Engine Start Up 
                 // Or F9 as multiple sounds on other decoders
    DELAY(1000)  // wait 1 secomnd
    FON(2)       // F2 Loco Whistle/Horn on
    DELAY(2000)  // wait 1 long Whistle/Horn
    FOFF(2)      // Whistle/Horn  off
    FWD(25)      // Move forward at speed 25
    DELAY (4000) // Run for 4 seconds & Stop
    STOP         // then stop
    DELAY(3000)  // Wait 3 seconds
    PRINT ("Set Reverse auto Bell On, 2x Whistle/Horn, speed 25 for 4 seconds STOP and Wait for Dispatch")
    FON(2)       // Whistle/Horn
    DELAY(250)
    FOFF(2)      // Whistle/Horn Off
    DELAY(750)
    FON(2)       // Whistle/Horn
    DELAY(250)
    FOFF(2)      // Whistle/Horn Off
    FON(1)       // Bell On
//  FON(6)       // FX6 Special Effect On
    REV(25)      // reverse at speed 25
    DELAY(4000)  // Run 4 Seconds
    FOFF(1)      // Bell Off
    DELAY(200)
//  FOFF(6)      // FX6 Effect Off
    STOP         // then stop
    DELAY(1000)
    FWD(0)       // Set Forward, Lights On
    DELAY(250)
    FON(4)       // Steam or Coupler On
    //  Commented out to allow the Engine to be Acquired/Selected and to "Drive Away" off of the Prog onto the Main Track
    FOFF(3) DELAY(250)
    FON(3) DELAY(250) FOFF(3) // MTH Shut Down Engine then Set MTH Decoder F3 Announcement Off
    DELAY(500)
    FOFF(9)      // Paragon Decoder Shut Down Engine Off
    DELAY(3000)
    FOFF(4)      // Steam Off Or Coupler Off or F4 Off
    PRINT ("Acquire/Select the Engine # on your Throttle and 'Drive Away' off of the Prog track onto the Main track")
    PRINT ("Or STOP and Wait for Dispatch Or Replace another Engine On the Prog track to test again")
    PRINT ("Send '</START 201>' again OR on Engine Driver & WiThrottle Press the 'EXRAIL 201' button to Run it Again")
    DONE         // Done, Re-Start it again to test another Loco

//*************************************** End of Lesson 201  ****************************************************** //
// **************************************************************************************************************** //


//***************************************************************************************************************** //
// Lesson Automation 202 from Engine Roundhouse to Turntable Back & Forth - Timed                -- Tinkerer Level
// **************************************************************************************************************** //
/* // AUTOMATION Lesson 202 Simple Engine Back & Forth on the Main Line - TIMED   Enginehouse to Turntable
   // Automation for DCC++EX EXRAIL to run from Engine Driver & WiThrottle App
   // Loco Driving from Roundhouse onto Turntable then Back. Timed B&F
   // Adjust the DELAY (xxx) seconds Travel time to match your required distances 
   //
   //  Roundhouse  =======>>>======<<<========= Turntable
   //  START here         drive >-<             Wait x sec

   Place a DCC ready Loco in Roundhouse to Turntable track or on a Mainline spur track.
*/

  AUTOMATION(202, "EXRAIL 202 Roundhouse to Turntable Back & Forth - Timed") // Or Shuttle or Trolley
  // SETLOCO(1225) // You may Manually Replace this 1225 with your Engine numbers 1 to 10239,
                  //  'Don't use search & replace or Gremmlins popup.'
   POWERON       // Power All Tracks ON
   FWD(0)       // Set to Forward
   FON(0)      // F0 Headlight On
   DELAY(500)
   PRINT ("Short F2 Whistle or Horn immediately to Acknowledge Acquired")
   FON(2)      // Sound Whistle/Horn
   DELAY(100)  // Short Whistle/Horn 
   FOFF(2)     // Horn Off
   PRINT("")
   PRINT ("EXRAIL Automated Throttle Control by KC Smith, Modified August 15, 2021")
   PRINT ("You've Pressed the EXRAIL 202 Turntable B&F Timed [HandOff] button")
   PRINT ("Wait until it Stops back in the Roundhouse and Press it again to Repeat")
   DELAY(1000)
   FON(2)       // F2 Whistle/Horn on
   DELAY(1500)  // wait 1.5sec Long Whistle/Horn
   FOFF(2)      // Whistle/Horn off
   DELAY(1000)  // Here we go
   PRINT ("Loco Forward speed 20 for 10sec, Then Stop on Turntable & wait 6 sec")
   FWD(20)      // Move forward at DCC speed 20 {Speed is determined by each engines DC Motor speed and vdc on the track}
   DELAY(10000) // wait 10 seconds
   STOP         // then stop
   DELAY(6000)  // Wait 6 seconds
   PRINT ("Set Loco in Reverse")
   PRINT ("FX6 Bell & Blow Whistle/Horn Thrice")
   PRINT ("Release Break Proceeds back into Roundhouse")
   PRINT ("F1 Bell On, F2 Whistle/Horn thrice, Reverse speed 25 for 9 5sec")
   FON(1)       // Bell On
   DELAY(200)
   FON(2) DELAY(750) FOFF(2) DELAY(500) FON(2)DELAY(750) FOFF(2)DELAY(500) FON(2) DELAY(750) FOFF(2)// Horn On Three Toots
   DELAY(2000)
   REV(20)      // reverse at DCC speed 20
   DELAY(9000)  // wait 9sec
   PRINT ("Loco Slow down 15 reverse")
   SPEED(15)    // reverse at speed 15
   DELAY(1500)  // wait 1.5sec
   PRINT ("Turn Off Bell & Blow Whistle/Horn Once")
   FOFF(1)      // Bell off 
   DELAY(200)
   FON(2)       // Horn sounding
   DELAY(500)   // wait .5 Seconds
   FOFF(2)      // Horn sounding
   DELAY(200)
   FON(3)       // Short Whistle or Clank Sound
   DELAY(500)
   FOFF(3)
   PRINT ("Set PE 1225 Forward & Stop") 
   FWD(10)      // Forward speed 10
   DELAY(250)   // wait .25sec 
   FWD(0)       // STOP
   DELAY(200)
   FON(4)       // Steam or Safety Valve sound
   DELAY(750)   // wait .75sec
   PRINT ("")
   PRINT ("Loco Waiting in Roundhouse for Work Crew and Maintenance Repairs")
   PRINT ("End of the EXRAIL Automation 202, Decide what Should I do Next?")
   PRINT ("")   
   PRINT ("Either, Push 'EXRAIL 202 Turntable B&F Timed' button to Run it Again")
   STOP         // Then Stop
   DELAY(3000)
   FOFF(4)      // Steam Off Or Coupler Off or F4 Off
   PRINT("Ready to run Next Automation{Handoff} or a Route{Set} button & Manually Drive an Engine Away")
   ENDTASK      // End Automation 202

//*************************************** End of Lesson 202  ****************************************************** //
// **************************************************************************************************************** //


//***************************************************************************************************************** //
// Lesson Automation 203 Engine from Station A to Station B - 2 Sensors Back & Forth Trolley    -- Tinkerer Level
// **************************************************************************************************************** //
 /* AUTOMATION Lesson 203 Simple Trolley Back & Forth with Sensors on the Main Line - SENSORS
  *  Automation for DCC++EX EXRAIL to run from Engine Driver & WiThrottle App
  *  Loco Driving from Station A to B then Back with Sensors B&F
  *   Wait 6 seconds for Dispatcher to shuffle off and on, then repeat
        
       {Sns22}                               {Sns23} Sensors
       Station A =======>>>=======<<<======= Station B
      Start here           > drive <         Wait x sec

  * Sensors Sns22 & Sns23 are connected to the Mega pins D22 & D23 additional sensors can connect on D24 & D25
 */

  AUTOMATION(203, "EXRAIL 203 Station A to B Sensors")
  IF(213)        // One button push to latch dummy 213pin and prevent mutliple WiThrottle button presses
   UNLATCH(213)  // After a second button press Unlatch and Return to the Start and ENDTASK  
    STOP FWD(0) FOFF(1)
     PRINT("STOP EXRAIL 203 Station A to B Sensors STOPPED")PRINT("")
   DONE 
  ENDIF
   LATCH(213)
    FOLLOW (803)
   
  SEQUENCE(803)
  // SETLOCO(1225) // You may Manually Replace this 1225 with your Engine numbers 1 to 10239,
                  //  'Don't use search & replace or Gremmlins popup.'
   POWERON       // Power All Tracks ON
   FON(0)       // F0 Headlight On
   DELAY(500)
   PRINT ("Short F2 Whistle or Horn immediately to Acknowledge Acquired")
   FON(2)      // Sound Whistle/Horn
   DELAY(100)  // Short Whistle/Horn 
   FOFF(2)     // Horn Off
   PRINT("")
   PRINT ("EXRAIL Automated Throttle Control by KC Smith, Modified April 2022")
   PRINT ("You've Pressed the EXRAIL 203 Station A to B Sensors [HandOff] button")
   PRINT ("Wait until it Stops back at Station A and Press it again to Repeat")
   FWD(0)       // Set to Forward
   DELAY(200)
   FON(2)       // F2 Whistle/Horn On
   DELAY(1000)  // wait 1 seconds
   FOFF(2)      // Whistle off
   PRINT ("Loco Forward speed 25 to Sensor {Sns23} Station B, Then Stop & wait 6 sec")
   FWD(25)      // Move forward at DCC speed 20 {Speed is determined by each engines DC Motor speed and voltage on the track}
   AT(23)       // At Sensor {Sns23}
   STOP         // then stop
   DELAY(6000)  // Wait 6 seconds Wait for Dispatcher
   PRINT ("Set Loco in Reverse")
   PRINT ("Bell & Blow Whistle/Horn Thrice")
   PRINT ("Release Break Proceeds back to Station A")
   PRINT ("F1 Bell On, F2 Whistle thrice, Reverse speed 25")
   FON(1)       // Bell On
   DELAY(200)
   FON(2) DELAY(750) FOFF(2) DELAY(500) FON(2)DELAY(750) FOFF(2)DELAY(500) FON(2) DELAY(750) FOFF(2)// Horn On Three Toots
   DELAY(2000)
   REV(25)      // reverse at DCC speed 25
   AT(22)       // At Sensor {Sns22}
   STOP
   PRINT ("Turn Off Bell & Blow Whistle Once")
   FOFF(1)      // Bell off 
   DELAY(200)
   FON(2)       // Horn sounding
   DELAY(500)   // wait .5 Seconds
   FOFF(2)      // Horn sounding
   DELAY(200)
   FON(3)       // Short Whistle or Clank Sound
   DELAY(500)
   FOFF(3)
   PRINT ("Set Loco Forward & Stop") 
   FWD(10)      // Forward speed 10
   DELAY(250)   // wait .25sec 
   FWD(0)       // STOP
   DELAY(500)
   FON(4)       // Steam Off Or Coupler Off or F4 Off
   DELAY(3000)  // wait 2sec
   FOFF(4)
   PRINT ("")
   PRINT ("Loco Waiting at Station A for Passengers to Board")
   PRINT ("End of the EXRAIL Automation 203, Decide what Should I do Next?")
   PRINT ("")
   PRINT ("Please Push EXRAIL 203 Station A to B Sensors B&F button to run it Again")
   STOP         // Then Stop
   PRINT("")
 //ENDTASK      // Uncomment this Line to End Automation 203
  IF(213) FOLLOW(803) ENDIF  // loop 803 until 213unlatched then Print & done
   PRINT("Ready to run Next Automation{Handoff} or a Route{Set} button & Manually Drive an Engine Away")
   PRINT ("Or, Press 'EXRAIL 203' button to Run it Again")
   DONE

//*************************************** End of Lesson 203  ****************************************************** //
// **************************************************************************************************************** //


//***************************************************************************************************************** //
//                                                                                               -- Tinkerer Level
// Lesson Automation 204 Engine from Station A to Station B - 2 Sensors & 2 Turnouts Multi Tracks Back & Forth
// **************************************************************************************************************** //  
/* AUTOMATION Lesson 204 Engine  Back & Forth - Sensors & Turnouts from Two Tracks
 *   On the Second run you can edit the script, Engineer Decides on which way to head to Station A from B
 *    {Either Reverse on Tracks A, or Forward forward on Tracks B, IF you have a loop} 
 *     See the script below and Comment Out one of them. The Default is reverse on track A
 *    
 *   Automation for DCC-EX EXRAIL to run from Engine Driver & WiThrottle App
 *   Dispatch Eng 1225 Driving from Station A to B then Back with 2 Sensors and 2 Turnouts B&F  
 *  {After the Second run You may Edit the script & Change the REV to a FWD Direction and Continue on a Loop on Track B}
                         Track A
               =========<<<====<<<=======
              //                         \\
             // R/G Led          R/G Led  \\
    Sns22   // 106/107           108/109   \\   Sns23          
    START-=======<<<=======>>>==========>>>========= Water Tower  << Edit either the third REV or Fwd  >>
  Station A   T1         Track B          T2           Station B
            Vpin101                    Vpin102

 *  Servos & Signals are connected on a PCA9685 {SCL, SDA, VCC, Gnd} to Mega pins {SCL, SDA, 5V, Gnd}. 
 *   Plus a separate 5vdc wallwart to connected to the PCA9685 terminal block V- V+.
 *  Servo turnouts T1 & T2 are connected on vpin101, Vpin102 and 
 *  Place two Red|Green LED turnout point signals on vpins Red 106 & 108 and Green 107 & 109
 *  Sensors Sns22 & Sns23 are connected to the Mega pins D22 & D23 additional sensors on D24 & D25  if desired
 *  Optional Momentary Panel Push buttons for turnouts are directly connected on the Mega pins D31 & D32 and to Gnd

 */
  AUTOMATION(204, "EXRAIL 204 Station A to B Sensors & Turnouts")
   IF(214)       // One button push to Latch dummy 214pin and prevent mutliple WiThrottle button presses
    UNLATCH(214) // After a second button press Unlatch and Return to the Start and ENDTASK 
    AT(23) STOP  // AT Sensor Sns23 STOP & Throw T2 & T1 and proceed to Park at Sensor Sns22 at Station A
     PRINT ("Your Scheduled Shift is Over, Please Proceed Back To Station  A")
      CALL(22)
       CLOSE(2) DELAY(750) 
       CLOSE(1)
      FON(1)     // F1 Bell On
     REV(20)
    AT(22) SPEED(0) // at sensor 22 Stop and Park at Station A
     RESET(114) RESET(115) // Caution Signal Off
      FOFF(1)                   // F1 Bell Off
      FON(2) DELAY(250) FOFF(2) // Whistle/Horn 
       STOP
      PRINT("STOP EXRAIL 204 Station A to B Sensors & Turnouts - STOPPED")PRINT("")
     PRINT ("End of the EXRAIL Automation 204, Proceed Back to Station A")
    DONE 
  ENDIF
   LATCH(214)
    FOLLOW (804)
     
  SEQUENCE(804)   
   PRINT ("EXRAIL Automated Throttle Control by KC Smith, Modified April 2022")
   PRINT ("You've Pressed the EXRAIL 204 Station A & B Sensors & Turnouts [Handoff] button")
   PRINT ("The Train Will Run Back & Forth on Tracks A & B")
   PRINT ("OR Edit the script to Run Forward on a Loop Circle Track B from Station A to Station B")
   PRINT (" Depending on What You the Engineer Decide ")PRINT("")
   PRINT ("Press the Engine Driver {Handoff} or WiThrottle{Route} button a Second time to End the Run and Return to Station A")
   PRINT ("Wait until it Stops back in at Station A Then Choose another Automation(n)")
   
  //SETLOCO(1225)  // You may Manually Replace this 1225 with your Engine numbers 1 to 10239
                  // 'Don't use search & replace or Gremmlins popup.'
   POWERON       // Power All Tracks ON
   FON(0)       // F0 Headlight On
   DELAY(500)
   PRINT ("Short F2 Whistle or Horn immediately to Acknowledge Acquired")
   FON(2)       // F2 Sound Horn
   DELAY(100)   // wait Short Whistle/Horn 
   FOFF(2)      // Horn Off
   DELAY(1000)
   PRINT("")
   CLOSE(1)     // Set Turnout 1
   DELAY(1000)
   CLOSE(2)     // Set Turnout 2
   DELAY(1000)
   FON(2)DELAY(500)FON(2) //  F2 Whistle/Horn on
   DELAY(1500)  // wait 1 seconds Long Whistle/Horn
   FOFF(2)      // Whistle/Horn off
   DELAY(1000)  
   PRINT ("Loco Forward speed 25 to Sensor{Sns23} Station B, Then Stop & wait Random 6-10 seconds")
   FWD(25)      // Move forward at DCC speed 25 {Speed is determined by each engines DC Motor speed}
                // Travel Time
   AT(23)       // At Sensor {Sns23}
   PRINT("Arrived at Station B, Passengers Depart")PRINT("")
   STOP        
   FON(2)DELAY(400)FOFF(2) // F2 Whistle/Horn   
   DELAYRANDOM(6000,10000)
   
  // Return in Reverse to on Track B to Station A 
   PRINT("Return to Station A on Track A")PRINT("")
   PRINT ("Bell & Blow Whistle/Horn  Twice")
   FON(2) DELAY(200)FOFF(2) DELAY(750) FON(2)DELAY(200)FOFF(2) // Whistle/Horn On Two Toots
   PRINT ("F1 Bell On")PRINT("")
   FON(1)       // Bell On
   DELAY(200)
   THROW(2)     // Set Turnout 2
   DELAY(1000)
   THROW(1)     // Set Turnout 1
   DELAY(800)
   REV(25)      // Reverse Back on Track A to Station A at DCC speed 25
                // Travel Time
                 
   AT(22)       // At Sensor {Sns22}
   PRINT ("Arrive at Station A")
   STOP
   PRINT ("Turn Off Bell & Blow Whistle/Horn Once")
   FOFF(1)      // Bell off 
   DELAY(200)
   FON(2)DELAY(500)FOFF(2) //F2 Whistle/Horn sounding
   DELAY(1000)
   FON(3)DELAY(500)FOFF(3) //F3 Clank Sound or a Short Whistle/Horn
   PRINT ("Set Loco Forward & Stop")PRINT("")
   FWD(10)      // Forward speed 10
   DELAY(250)   // wait .25sec
   FWD(0) STOP  // STOP
   DELAY(500)
   FON(4) DELAY(3000) FOFF(4)  // Steam or Safety Valve sound
   PRINT ("Train Waiting at Station A for Passengers to Board")PRINT ("")
   DELAYRANDOM(6000,8000)  // Random Delay 6-8 Seconds then Proceed

   PRINT("Loco Departs for Station B again")
   PRINT("Forward speed 25 to Sensor{Sns23} Station B, Then Stop & wait Random 6-8 seconds")
   FON(2)DELAY(400)FOFF(2)DELAY(250) FON(2)DELAY(400)FOFF(2)  // F2 Whistle/Horn  
   FWD(25)      // Move forward at DCC speed 25 {Speed is determined by each engines DC Motor speed}
                // Travel Time
   AT(23)       // At Sensor {Sns23}
   PRINT("Arrived at Station B, Passengers Depart")PRINT("")
   STOP        
   FON(2)DELAY(500)FOFF(2)  // F2 Whistle/Horn 
   
   PRINT (" On the Second run have the Engineer Decides on which way to head to Station A")
   PRINT (" {Either Reverse or Forward} See Automation(204) and Edit script")
   PRINT ("Release Break Proceed to Station A")
   DELAYRANDOM(6000,8000)  // 6 to 8 seconds Wait for Dispatcher
   
// CHOOSE Either to <Reverse Return OR Continue Forward> on Circle Track B to Station A 
// Comment Out /*  */  one and Uncomment the other Direction [FWD] REV] function

  // Return in Reverse to on track B to Station A 
   PRINT("Return to Station A on Track A")PRINT("")
   PRINT ("Bell & Blow Whistle/Horn  Twice")
   FON(2) DELAY(200)FOFF(2) DELAY(750) FON(2)DELAY(200)FOFF(2) // Whistle/Horn On Two Toots
   PRINT ("F1 Bell On")PRINT("")
   FON(1)       // Bell On
   DELAY(200)
   THROW(2)     // Set Turnout 2
   DELAY(1000)
   THROW(1)     // Set Turnout 1
   DELAY(800)
   REV(25)      // Reverse Back on Track A to Station A at DCC speed 25
                // Travel Time
/*
  //OR Continue Forward on Circle Track B to Station A at DCC Speed 30
   PRINT("Continue to Station A on Track A")PRINT("")
   PRINT ("Blow Whistle/Horn Twice")
   FON(2) DELAY(250)FOFF(2) DELAY(500) FON(2)DELAY(250)FOFF(2) // Whistle/Horn On Two Toots 
   FWD(30)      // Forward around to Station A
                // Travel Time
*/                
   AT(22)       // At Sensor {Sns22}
   PRINT ("Arrive at Station A")
   STOP
   PRINT ("Turn Off Bell & Blow Whistle/Horn Once")
   FOFF(1)      // Bell off 
   DELAY(200)
   FON(2)DELAY(750)FOFF(2) //F2 Whistle/Horn sounding
   DELAY(700)
   FON(3)DELAY(500)FOFF(3) //F3 Clank Sound or a Short Whistle/Horn
   PRINT ("Set Loco Forward & Stop")PRINT("")
   FWD(10)      // Forward speed 10
   DELAY(250)   // wait .25sec
   FWD(0) STOP  // STOP
   DELAY(500)
   FON(4) DELAY(3000) FOFF(4) // Steam or Safety Valve sound
   PRINT ("Train Waiting at Station A for Passengers to Board")PRINT ("")
   DELAYRANDOM(6000,10000)    // Random Delay 6-10 Seconds then Proceed
   
 //ENDTASK      // Uncomment this line to End Automation 204 and wait at Station A
 //Or
   IF(214) FOLLOW(804) ENDIF  // loop 804 until 214unlatched then Print Message & done
   PRINT("Ready to run Next Automation{Handoff} or a Route{Set} button to Manually Drive an Engine")
   PRINT ("OR, Press EXRAIL 204 Station A & B Sensor & Turnouts button to Run the Script Again")
   DONE            

// *************************************** End of Lesson 204  ****************************************************** //
// **************************************************************************************************************** //


// ******************************************************************************************************************** //
//                                                                                              -- Tinkerer High Level
// Lesson Automation 205 Engine from Station A to Station B - 3 Sensors & 2 Turnouts 1 Accessory Servo5 & DFPlayer MP3
// Note; The Following Automation works with a DFPlayer mini Micro-SD card MP3 Sound Player.  See myHal.cpp setup
// ******************************************************************************************************************* //
 /* Automation(205) is an automation example for a single loco Two Track A & B journey
 *   Train runs from Station A START and proceeds on Track B to Station B Water Tower, DFPlayer plays Two Sounds.
 *       Close  T1 Straight  Track B  delay Close T2 Straight, Engine FWD DCC speed
 *       Arrives at Sns23 at Station B or the Water Tower and starts MP3 Player 'Filling Water Tank'
 *       Then back on Track A to Trip sensor Sns24 with 'Train Arrival' sound then to sensor Sns22, at Station A.
 *        Throw  T2 Right  Track A  Throw T1 Left, Engine REV DCC speed 23%
 *       Arrives at Station A where RailFans greets them with Servo 5 walking movement
 *       Wait 22 seconds for Dispatcher to clear them then 'All Aboard' playes and repeats
 *       
 * Start at Station A Sns{22} on Track B, Turnouts Close-Green, 
 *  Engine Sounds Whistle/Horn proceeds Forward to Station B Water Tower Tank Ariives and stops at Sns{23} 
 *  trips DFPlayer “Request Maintenance for 200 liters of Water” then “Water Filling Tank sound”, after xx seconds then
 *  Turnouts Throw-Red to Track A, Loco Bell & Whistle/Horn sound then proceed in Reverse on Track A to Sns{24} 
 *  trips the DFPlayer “Announcement Arrival Station A on Track A” then trips Flashing Caution Signals.
 * Arrives at Station A trips Sns{22} Stops Caution Signals & trips [AS5] Railfan greats the Engine then DFPlayer “Sound effect”.
 * After a Delayed Random time DFPlayer calls “All Aboard” and the cycle repeats from Station A to Station B and back again.

       
   Caution Signals 
   vpin114  vpin115 
        X_||_X                                      
          ||                
  
   T5 vpin105                  Track A             
    Railfans   ===============<<<====>>>==================   
     Walks    //               +Sns{24}                  \\
             //  R/G Led                         R/G Led  \\          DFPlayer MP3 Sound      
    Sns22   // 106/107         +Sns{25}           108/109  \\       Sns23   
  Start-===================>>>=========>>>=============== =========== Water Tower
 Station A  T1                 Track B                      T2         Station B
        Vpin101                                         Vpin102

 *  Servos & Signals are connected on a PCA9685 {SCL, SDA, VCC, Gnd}to Mega pins {SCL, SDA, 5V, Gnd}. 
 *    Plus a separate 5vdc wallwart to connected to the PCA9685 terminal block V- V+.
 *  Servo turnouts T1 & T2 are connected on vpin101, Vpin102 and Accessory Servo T5 connected on vpin105
 *   for a Slow Motion Person Walking, glued to the end of a thin curved piece of wire on the servo arm.
 *  Place the Red|Green LED turnout point signals on vpins Red 106 & 108 and Green 107 & 109 and the
 *  Caution Lights {2 Yellow LEDs} Or Crossing Signal{2 Red LEDs} on the PCA9685 Board {Vpins 114 & 115}
 *  Sensors Sns22, Sns23 & Sns24 are connected to the Mega pins D22, D23 &D24 additional sensor D25 if desired
 *  Optional Panel Push buttons for turnouts are directly connected on the Mega pins D31 & D32 & D35 then to Gnd
 *  A Optional DFPlayer MP3 can be connected on the Virtual pin2000 and sounds on vpin 1500-1514
 */
 AUTOMATION(205, "EXRAIL 205 Station A & Station B - Water Tower +MP3") // Station A to Station B, Water Tower & Back
  IF(215)        // One button push to virtual Latch dummy 215 and prevent mutliple WiThrottle button presses
   UNLATCH(215)  // After a second button press Unlatch and Return to the Starting point and ENDTASK 
    AT(23) STOP  // AT Sensor Sns23 STOP & Throw T2 & T1 and proceed to park at Sensor Sns22 on Station A
     PRINT ("The Water Tank Is Full of 3M Moonshine & the FBI is in route, High Tail it back to Station A")
      CALL(22)
      CLOSE(2) DELAY(750) 
      CLOSE(1)
     FWD(20)
    AT(22) SPEED(0) // at sensor 22 Stop and Park at Station A
     RESET(114) RESET(115)
      FON(2) DELAY(250) FOFF(2) // Whistle/Horn
       FON(4)DELAY(4000)FOFF(4) // Steam valve release
       PRINT("STOP Automation 205 Station A to Station B  Water Tower ~STOPPED")PRINT("")
     PRINT("End of the EXRAIL Automation 205, Proceed Back to Station A")
    ENDTASK
  ENDIF
   LATCH(215)
   FOLLOW (805)
   
 SEQUENCE(805)
   PRINT ("You've Pressed the 'EXRAIL 205 Station A to Water Tower' [Handoff] button to Run Engine B&F to Fill Water Tank.")
   PRINT ("Enhanced EXRAIL Automated Throttle Control Plus MP3 Sound Player by KC Smith SCMRRC Member, Modified December 1, 2021")
   PRINT ("Automation 205 one Loco Leaves Station A on Track B to Staion B Water Tower, Fill Engine with Water then return on Track A")
// SETLOCO(3)  // You may change the Loco#3 to any number from 1 to 10239 to match the CAB number on the side of your Engine

   POWERON     // Power All Tracks ONFON(0) // F0 Headlight On
   FON(0)      // F0 Head Lights
   DELAY(500)
   PRINT ("Short F2 Whistle or Horn immediately to Acknowledge Acquired")
   FON(2)      // F2 Sound Whistle/Horn
   DELAY(100)  // Short Whistle/Horn
   FOFF(2)     // Horn Off
   DELAY(1000)
   PRINT("")
// Note; Different Decoders need certain F-Keys pressed to start ther Engines Please uncomment those that apply to your engine Decoder Mfr.
// FON(3)      // Special {F3} Engine Startup for MTH Decoders, 
// FON(8)      // Special (F8) Mute button ON StartUp for ESU Decoders,
// FON(9)      // Special {F9} Engine Startup for QSI-Paragon3 decoders.
  
 // Extra Servo for Animation and Accessories only used with a addon PCA9685 Servo Controller boards
 // Accessory T5 Servo Vpin 105 with a long curved wire 180 degree rotation for a Person Walking or move a Gate Or Water Spout
   PRINT("")   // Space between print lines
   PRINT ("Railfan Walking Away, back into the Annex or Drive-In lot.") // T5 SERVO vpin105 long curved wire 180 degree rotation 
   CALL(101)   // Railfans  Walking away from Engine Call SEQUENCE(101)Macro - Counter Clockwise
               // RETURN here from Call Sequence(101)
   PRINT ("Close Turnout T1, then Close T2 and Proceed, Loco Reverse speed 28 on Track B to sensor 23 {Sns23 pinD23} Station B Water Tower")
   CLOSE(1)           
   DELAY(600)
   CLOSE(2)
   PRINT ("Close T2 Track B, Set LED Green") // Close Switch T2 Left for Track B route to sensor 23
   DELAY(3000)
   
   PRINT ("Loco Blow Horn, Forward speed 28 until sensor 23 {Sns23}, Then Stop")
   FWD(127*.28)        // go Forward at DCC speed 28
   AT(-22)             // Leaving Station Sensor {Sns22} Horn Signal
   PRINT("Left Station Blow Horn")
   FON(2) DELAY(1500) FOFF(2) DELAY(1500) FOFF(2)// Blow Whistle/Horn twice when we leave to 1st sensor 23, Sound Horn again
   PRINT ("Caution or Crossing Signal Lights")
   CALL(23)           // Sequence 23 Crossing Signals On Until you reach sensor {Sns23}
                      // Travel Time
   AT(23) STOP        // Arrived at Water Tower Fill
   PRINT("Arrive at Station B {Sns23} Stop")

// Special Effect, Instead of a RailFan walking you could use a Accessory servo vpin (100) or (105) to move a water Tower Spigot Back & Forth
   CALL(101)        // Walking Person - Counter Clockwise, OR Lower Water Tank Spigot to fill Water Tank SEQUENCE(n)Macro for Servo
   DELAY(1000)

   PRINT("Optional DFPlayer MP3 Sound of Water Filling Tank")  // Pick one of the following two MP3 Sequences
// A DFPlayer MP3 Mini Sound card sequence.  SEE myHal.cpp #define DFPlayer for details
   SET(1504)        // DFPlayer 5th File on vpin 1504 Engineer Request Maintenance Fill 200 Liters of Water
    WAITFOR(1504)   // Wait for the first vpin sound to play the Full Length of Sound
   RESET(1500)      // Stop DFPlayer
    DELAY(1000)
   SET(1505)        // DFPlayer 6th File on vpin 1505 Water Filling Tank  {60 sec long}
 // WAITFOR(1505)   // Wait for the first vpin sound to play the Full Length of Sound
    DELAY(10000)    // OR only play the first X seconds of the file
   RESET(1500)      // Stop DFPlayer
    DELAY(1000)

   PRINT ("Throw Turnouts T1, then Throw T2 and Proceed Forward speed 25 on Track A to sensor {Sns23} Station B")
   THROW(2)
   DELAY(600)
   THROW(1)
   PRINT ("F2 Whistle or Horn Twice")
   FON(2) DELAY(500) FOFF(2)  // Sound Horn .5sec Horn Off
   DELAY(500)
   FON(2) DELAY(500) FOFF(2)  // Sound Horn .5sec Horn Off
   DELAY(1000)
   PRINT ("Return to Station A via Track A Route")

   FON(1) DELAY(100) FON(6) DELAY(100) // Bell On & Special FX {F6} Running Board Strobe Lights on the Engine 3 ESU Sound Decoder
   REV(127*.25)               // go Reverse at DCC speed 25
   PRINT("Left Station Blow Horn")PRINT("")

// Optional Sensor{24} on Track A, Trips DFPlayer Sound
   AT(24)
   PRINT("Engine Arriving at Station A on Track A")PRINT("")
   SET(1508)        // DFPlayer 6th File on vpin 1508 Arrival Announcement
    WAITFOR(1508)   // Wait for the vpin sound to play the Full Length of Sound
   RESET(1500)      // Stop DFPlayer
    DELAY(1000)
   PRINT ("Caution or Crossing Signal Lights")
   CALL(22)         // Caution Or Crossing Signals Until you reach sensor {Sns22}
                    // Travel Time
   AT(22)
   STOP // IDLE // when we arrive at sensor 22 {Sns22}
   FOFF(1) DELAY(100) FOFF(6) // BELL & Running Lights Off At Sensor 22
   PRINT ("Loco Stopped at Station A sensor 22 {Sns22} Wait 10sec for Dispatcher")
   PRINT("Arrived at Station A,  Play Sound of 'Optional MP3 Sound Player'")
   SET(1510)        // DFPlayer Big Ben Chime
   WAITFOR(1510)    // Wait for the file on vpin1510 to end
   RESET(1500)      // Stop DFPlayer
   PRINT ("RailFans walking out to take Pictures")
   // Extra Servo for Animation and accessories only used with addon PCA9685 Servo Controller boards
   CALL(100)                 // RailFans walk out to take Pictures SEQUENCE(100)Macro
   DELAYRANDOM(3000, 10000)  // Random wait an additional 3-10 seconds for Passengers and for Sound to play

// Optional Station A Announcement DFPlayer Sound
  
   PRINT("All Aboard")PRINT("")
   SET(1507)        // DFPlayer 8th File on vpin 1508 All Aboard
    WAITFOR(1507)   // Wait for the vpin sound to play the Full Length of Sound
   RESET(1500)      // Stop DFPlayer
    DELAY(1000)
    
  IF(215) FOLLOW(805) ENDIF // loop 805 until 215unlatched then Print & done
     PRINT("Ready to run Next Automation {Handoff} or a Route{Set} button & Manually Drive an Engine")
     PRINT("Or, Press 'EXRAIL 205' button to Run it Again")
   DONE
   
// *************************************** End of Lesson 205  ****************************************************** //
// **************************************************************************************************************** //
  
// ******************************************************************************************************************** //
//                                                                                              -- Tinkerer High Level
// *Lesson Automation 206 DC CAB from Station B to Station A - 3 Sensors & 2 Turnouts 1 Accessory Servo5 & DFPlayer MP3
//  * DC CAB capability is still in Development & Testing v5.0
// Note; The Following Automation works with a DFPlayer mini Micro-SD card MP3 Sound Player.  See myHal.cpp setup
// ******************************************************************************************************************** //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// The Following Automation(206) will run on v4.1 for DCC Engines as is. 
//  It is in testing with Dev-Release DCC-EX PORTX-HAL{4.2.4+} aka TrackManagerTM* V5.0 Legacy Analog DC CAB in a DCdistrict
//  To run a DC CAB You must install DCC-EX version 4.2.4+ or higher and Uncomment the SET_TRACK( )line below.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  NOTICE You are Stating at Station B in this Automation
/* AUTOMATION(206, "TM DCdistrict CAB B&F") TrackManager DCdistrict example for a single CAB from Station B to Station A & Back.
 *  DC CAB START from Station 'B' sensor Sns23 runs FWD to Sns22, then REV back to Sns23, multiple times on different tracks.
 *  Sensor Sns24 makes the Reversing CAB Stop on Track A for a Random amount of time then Sounds Bell & continue to Sns23.
 *  Mixing Track A & B each time with a Delayed Random wait at each stop.
 *  
 *  Includes a New Engine Driver Trottle IPLS 'In Phone Loco Sounds' feature for F1 BELL and F2 Horn/Whistle 
 *    sounds for DC & DCC Motor Only Locos.
 *   
 *  For Master V4.1 version to run DCC Engines Leave the line commented Out // SET_TRACK(B, DCX) to run a DCC Loco 
 *  For TrackManager v4.2.4 aka v5.0 with DCC & DC CAB Engines, Uncomment the // SET_TRACK(B, DCX) to run a DC & DCC Locos
 *  Note DCX sets Opposite Polarity for NMRA Modular Layouts rails R- L+ so you can Run your Engine & Throttle Direction correctly.
   
   Caution Signals 
   vpin114  vpin115 
        X_||_X                                      
          ||                
                        
    Railfan               Track A
    vpin105      ==========>>>>=<<<<=========              DFPlayer MP3 Sound
                //         Sns24             \\
               // 106/107            108/109  \\
    Sns22     // R/G LED   Sns25      R/G LED  \\   Sns23
      =====================<<<<<<=================== START  {START at Station B}
  Station A   T1          Track B               T2   Station B
             101                               102
  
 *  Servos & Signals are connected on a PCA9685 {SCL, SDA, VCC, Gnd} to Mega pins {SCL, SDA, 5V, Gnd}. 
 *    Plus a separate 5vdc wallwart to connected to the PCA9685 terminal block V- V+.
 *  Servo turnouts T1 & T2 are connected on vpin101, Vpin102 and Accessory Servo T5 connected on vpin105
 *   for a Slow Motion Person Walking, glued to the end of a thin curved piece of wire on the servo arm.
 *  Place the Red|Green LED turnout point signals on vpins Red 106 & 108 and Green 107 & 109 and the
 *  Caution Lights {2 Yellow LEDs} Or Crossing Signal{2 Red LEDs} on the PCA9685 Board {Vpins 114 & 115}
 *  Sensors Sns22 & Sns23 are connected to the Mega pins D22 & D23 additional ones on D24 & D25 if desired
 *  Optional Panel Momentary Push buttons for turnouts are directly connected to Mega pins D31 & D32 & D35 then to Gnd
 *  A Optional DFPlayer MP3 can be connected on the Virtual pin2000 and sounds on vpin 1500-1514
 */
 
  AUTOMATION(206, "EXRAIL 206 TM DCdistrict CAB Back & Forth") // Automated DC CAB Run back & forth
   IF(216)      // One button push to virtual latch dummy 216 and prevent mutliple WiThrottle button presses
   UNLATCH(216) // After a second button press Unlatch and Return to the Start and ENDTASK 
    AT(22) STOP // AT Sensor Sns22 STOP & Throw T2 & T1 and proceed to park at Sensor Sns23 on Station B
     PRINT ("TrackManager DC CAB Playtime is Over, Please Proceed Back To Station B")
      CLOSE(2) DELAY(750) 
      CLOSE(1)
     REV(20)
    AT(23) SPEED(0) // at sensor 23 Stop Park at Station B
     RESET(114) RESET(115)
      FON(2) DELAY(250) FOFF(2) // Whistle/Horn
      FON(4) DELAY(3000)FOFF(4) // F4 Steam valve release
     PRINT("STOP Automation 206 TM DCdistrict CAB Back & Forth ~STOPPED")PRINT("")
    PRINT("End of the EXRAIL 206, Proceed Back to Station B")
   DONE 
  ENDIF
   LATCH(216)
   FOLLOW (806)
   
 SEQUENCE(806)
   PRINT("")    // Line Space on serial monitor
   PRINT ("You've Pressed the EXRAIL 206 TM DCdistrict CAB B&F {HandOff} button to Run any DC or DCC Engine B&F")
   PRINT ("Set_Track to a DCX waveform with TrackManagerTM Command <= track, mode, DC address>")
 SETLOCO(3)   // You may change the Loco#3 to any number from 1 to 10239 to match the CAB number on the side of your Engine
   PRINT ("Set Loco on Either a DCC MAIN Track or a DCX Track")// Requires v4.2.4+ TrackManager to Set Track modes
// SET_TRACK(A, MAIN) // set track After Assigning the Engine. This track is DCC 
// SET_TRACK(B, DCX) // set track AFTER Assigning Engine, This track is DC facing in opposite direction
                    //**** DCC-EX V.4.2.4+ aka TrackManager v5.0 Required to SET_TRACK commands *****
   POWERON      // Power All Tracks ON
   FON(0)       // F0 Head Lights
   DELAY(500)
   PRINT ("Short F2 Whistle or Horn immediately to Acknowledge Acquired")
   FON(2)       // F2 Sound Whistle/Horn
   DELAY(100)   // Short Whistle/Horn
   FOFF(2)      // Horn Off
   DELAY(1000)
   PRINT("")
   PRINT ("Automated Throttle Control Back & Forth of DC Cab and DC Enabled DCC Locos starting at Station B")
   PRINT ("Set to Track A Then proceed Forward at speed 35")
   DELAY(500)   // wait .5 sec
   PRINT("Throw T2 to Route A Red")
   THROW(2)     // Throw T2 for Route A to sensor 22
   DELAY(1000)
   PRINT("Throw T1 to Route A Red")
   THROW(1)     // Throw T1 for Route A to sensor 22
   DELAY(500)
   
   PRINT("Railfan Walks Back to Station A")
   CALL(101)    // Sequence 101 Walking Person Servo 
   DELAY(5000)  // Clear the Area
   PRINT("Loco Forward speed 35 until sensor 22 {Sns22}, Then IDEL Stop")
   PRINT("Engine Driver IPLS 'In Phone Loco Sounds' for DC Cab & DCC Locos.  See Details in New Engiine Driver Features")
   FON(2) DELAY(500) FOFF(2) DELAY(1000) FON(2) DELAY(500) FOFF(2) //Whistle/Horn 
   DELAY(1000)  // Clear the area
   FWD(127*.35) PRINT("Engine Traveling FWD") // go forward at DC speed 35

   AT(24)       // Sns24  DFPLayer Announce Arrival
   PRINT ("Engine now Arriving at Station A, Please Stand Back & Clear the Tracks")
    SET(1508)   // Play Engine Arriving at Station A track A 9th file vpin1508
  //WAITFOR(1508)// Leave this Commented Out so the CALL(n) Trips quicker
  
   PRINT("X-CAUTION Signals ON Until you reach sensor 22 {Sns22}")
   CALL(22)     // Caution Or Crossing Signals Until you reach sensor {S22} 
    RESET(1500) // Turn DFPlayer OFF
    
   CALL(101)    // Railfan walks away from Tracks
                        
   PRINT("X-CAUTION Signals ON Until you reach sensor 22 {Sns22}")
   CALL(22)     //  Caution Signals
   
   AT(22) STOP  // when we get to 1st sensor 22
   PRINT("Arrive at Station A")
   PRINT("Railfan Walks Over to See the Engine")
   CALL(100)    // Walking Servo - Clockwise
   DELAYRANDOM(10000, 16000)  // wait 10 to 16 seconds 
   PRINT("Set to Track B, Close T1 & T2 Return to Station B")
   CLOSE(2)     // Close T2 for Route B to sensor 23
   DELAY(500)
   CLOSE(1)     // Close T1 for Route B to sensor 23
   PRINT ("Loco Reverse speed 35 until sensor 23 {Sns23}, Then Stop")
   
   PRINT("Railfan Walks Back to Station A")
   CALL(101)    // Walking Servo - Counter Clockwise
   DELAY(5000)  // Clear the area
   
   PRINT("Engine Driver IPLS 'In Phone Loco Sounds' for DC Cab & DCC Locos.  See Details in New Engiine Driver Features")
   FON(2) DELAY(500) FOFF(2) DELAY(250)
   REV(127*.35) PRINT("Engine Traveling in Reverse") // go backwards at DC speed 35
   
   AT(23) STOP  // IDLE // when we arrive at sensor 23 {Sns23}
   PRINT ("Arrived at Water Tower Station B")
   FWD(0)       // Set Forward
   PRINT ("Loco Stopped sensor 23 {Sns23} Wait 5 to 10 sec, then Fwd speed 30 until sensor 22 {Sns22}")
   DELAYRANDOM(5000,10000) // wait 5 to 10 seconds
   
   PRINT("Engine Driver IPLS 'In Phone Loco Sounds' for DC Cab & DCC Locos.  See Details in New Engiine Driver Features")
   FON(2) DELAY(500) FOFF(2) DELAY(1000) FON(2) DELAY(500) FOFF(2)
   FWD(127*.30)   PRINT("Engine Traveling FWD") // go forward at DCC speed 30

   AT(25)
   PRINT ("Engine now Arriving at Station A on Track B, Please Stand Back & Clear the Tracks")
    SET(1509)      // Play Arriving Station A Track B on vpin1509
  //WAITFOR(15009) // Leave this Commented Out so the CALL(n) Trips quicker
  
   PRINT("X-CAUTION Signals ON Until you reach sensor 22 {Sns22}")
   CALL(22)        // Caution Or Crossing Signals Until you reach sensor {S22} 
    RESET(1500)    // Turn DFPlayer OFF
    
   CALL(101)       // Railfan walks away from Tracks
   PRINT("X-Caution Signals on at RailFan site")
   CALL(22)        //CAUTION Signals ON until Engine Reaches sensor 22 {Sns22}
   
   AT(22)  STOP    // and stop at sensor 22
   PRINT("Loco Stopped at Station A sensor 22 {Sns22} Wait 10sec or more for Dispatcher")
   PRINT("Arrived at the Railfan site Station A")
   
   PRINT("Railfan Walks Out to see the Engine")
   CALL(100)       // Walking Servo - Counter Clockwise
   PRINT("Wait 15 to 18 Seconds then proceed")
   DELAYRANDOM(15000,18000)  // wait 10 to 13 seconds
   PRINT("Set to Track A then Reverse to Station B.")
   PRINT("Throw T1 to Route A")
   THROW(1)        // Throw T1 for Route A to sensor 23
   PRINT("Throw T2 to Route A")
   DELAY(500)
   THROW(2)        // Throw T2 for Route A to sensor 23
   DELAY(5000)     // Taking Photo of the Engine
   
   PRINT("Railfan Walks Back to Station A")
   CALL(101)       // Walking Servo back -Clockwise
   DELAY(5000)     // Clear the area
   PRINT ("Loco Reverse speed 35 until sensor 23 {Sns23}, Then IDEL Stop")
   PRINT("Engine Driver IPLS 'In Phone Loco Sounds' for DC Cab & DCC Locos.  See Details in New Engine Driver Features")
   FON(2) DELAY(500) FOFF(2) DELAY(1000)
   REV(127*.35)    // reverse back at DC speed 35
   PRINT("Traveling in REV")  
   
// Optional Feature with a third Sensor 24 {Sns24} in the middle of Track A.  To use this uncomment the following 9 lines
   AT(24) STOP     // AT 3rd sensor {Sns24} Stop with Random Delay
    PRINT("Engine Driver IPLS 'In Phone Loco Sounds' for motor only DC Cab & DCC Locos.")
    FON(2) DELAY(500) FOFF(2) // IPLS Short Whistle/Horn
    PRINT ( "Loco Stop at 3rd Sensor {Sns24} Wait Random seconds then continues at speed 30")
    PRINT("Wait 3 to 6 Seconds then Ring Bell and proceed")
    DELAYRANDOM(3000,6000) // Random wait 3 to 6 seconds 
    PRINT("Loco Continues to Station B Sensor {Sns23}") // loco coninuing to {Sns23}
    FON(1) DELAY(250) // IPLS Bell ON
    SPEED(127*.30)    // Slow Speed to 30
   
   PRINT ("Loco to Stop at sensor 23 {Sns23} Wait Random seconds, then Fwd speed 32 until sensor 22 {Sns22}")
   AT(23) STOP DELAY(100) FOFF(1)  // Stop & Bell Off
   PRINT("Arrive at Station B")    // when we arrive at sensor 23
   FWD(0)          // set Engine Forward
   PRINT("Railfan Walks Out at Station A to look down the Tracks to See where the the Engine is") 
   CALL(100)       // Sequence 100 Walking person
   
   PRINT("Wait 5 to 15 Seconds then proceed")
   DELAYRANDOM(5000,15000)   // Random wait 5 to 15 seconds
   
  //ENDTASK                  // or uncomment to run once and then Done.
  IF(216) FOLLOW(806) ENDIF  // loop 806 until 216unlatched then Print & done
   ESTOP
   PRINT("Ready to run Next Automation{Handoff} or a Route{Set} button & Manually Drive an Engine")  
   PRINT ("Or, Press 'EXRAIL 206' button to Run it Again")
  ENDTASK

//******************************* End of Lesson 206 DC CAB Back & Forth ****************************************** //
// *************************************************************************************************************** //


// ******************************************************************************************************************** // 
// *Lesson Automation 207 "Three Loco Rico Shuffle"                                             -- Tinkerer High Level
//  Testing EXRAIL RESERVE & FREE in Four Blocks on Station A to Station B layout             ** Not a Public Release **
// ******************************************************************************************************************** //
/* Automation(207) is an RESERVE & FREE Block automation example for a Three locos on Two Tracks A & B journey
 *   1st Loco moves from Station A START and proceeds to mid Track B {Sns26} & Stops 
 *   2nd Loco moves  back onfrom mid Track A to Station A {Sns22} & Stops
 *   3rd Loco moves from Station B to mid Track B {Sns24} & Stops
 *   Rinse & Repeat from Station A 
       
   Caution Signals 
   vpin114  vpin115 
        X_||_X                                      
          ||                
                              [BLOCK 4]
   T5 vpin105                 Track A             
   Railfans     ==============<<<====>>>=================   
               //              SNS[24}                  \\
              //                                         \\
             //  R/G Led                         R/G Led  \\      DFPlayer MP3 Sound      
    Sns22   // 106/107                            108/109  \\       Sns23   
 Start-===================>>>=========>>>========================== Station B
         T1 vpin101             Sns{25}                    T2 vpin102
         
 Station A  T1                 Track B                          
 [BLOCK 1]                    [BLOCK 2]                                [BLOCK 3]
 
 *  Servos & Signals are connected on a PCA9685 {SCL, SDA, VCC, Gnd}to Mega pins {SCL, SDA, 5V, Gnd}. 
 *    Plus a separate 5vdc wallwart to connected to the PCA9685 terminal block V- V+.
 *  Servo turnouts T1 & T2 are connected on vpin101, Vpin102 and Accessory Servo T5 connected on vpin105
 *   for a Slow Motion Person Walking, glued to the end of a thin curved piece of wire on the servo arm.
 *  Place the Red|Green LED turnout point signals on vpins Red 106 & 108 and Green 107 & 109 and the
 *  Caution Lights {2 Yellow LEDs} Or Crossing Signal{2 Red LEDs} on the PCA9685 Board {Vpins 114 & 115}
 *  Sensors Sns22, Sns23, Sns24, Sns25, Sns 26, Sns27 are connected to the Mega pins D22,D23,D24,D25,D26 & D27 
 *  Optional Panel Push buttons for turnouts are directly connected on the Mega pins D31 & D32 & D35 then to Gnd
 *  A Optional DFPlayer MP3 Mini card can be connected on Serial 1 with Virtual vpin1500-1509.  

 */

/*
 *  EXRAIL RESERVE Blocks and FREE Blocks Example 207: Running multiple inter-connected trains
 *  Loosely based on: https://tinyurl.com/EXRAIL-Example-7 
 *  Vid 1: https://youtu.be/BgbBqUjDQhE
 *  Vid 2: https://youtu.be/WlRzKQ4P3l0
 *  
 *                                   Engine
 *                               PE1225 (1225)
 *                                    ←
 *                         ┌─[ BLOCK 3 (Sns24) ]──┐
 *                         │                        │
 * ├─[ BLOCK 1 (Sns22) ]─┴─[(Sns25) BLOCK 2  ]──┴──[ BLOCK 4 (Sns23) ]─┤
 *            ↔           T1         →             T2          ↔
 *         Engine                                               Engine
 *     PE1204 (1204)            EMPTY / NO LOCO              PE1224 (1224)
 *    
 */

/*
 AUTOMATION(207, "EXRAIL 207 Three Loco Rico Shuffle") // Station A to Station B, and Track B & A
  IF(217)         // One button push to virtual Latch dummy 217 and prevent mutliple WiThrottle button presses
   UNLATCH(217)  // After a second {Set} button press Unlatch and Return to the Starting point and ENDTASK 
   AT(23) STOP  // AT Sensor Sns23 STOP & Throw T2 & T1 and proceed to park at Sensor Sns22 on Station A
    PRINT ("Loco Rico Shuffle is Over, Please Proceed Back To Station  A")
     CLOSE(2)DELAY(750) 
     CLOSE(1)
    FWD(20)
   AT(22) SPEED(0) // at sensor 22 Stop Park at Station A
    RESET(114) RESET(115)
     FON(2) DELAY(250) FOFF(2) // Whistle/Horn
     FON(4) DELAY(3000)FOFF(4) // F4 Steam valve release
      PRINT("STOP Automation 207 'Three Loco Rico Shuffle' ~STOPPED")
     PRINT("End of the EXRAIL Automation 207, Proceed Back to Station A")
   ENDTASK
  ENDIF
   LATCH(217)
   FOLLOW (807)
  
SEQUENCE(807)
   PRINT ("You've Pressed the 'EXRAIL 207 Three Loco Rico Shuffle'") // Three Engine Station A to Station B, and Track B & A")
   PRINT ("")
   PRINT ("!!! BEFORE </RESUME> place the Three Locos in Blocks 1, 3 & 4. Leave Block 2 Empty !!!")
   PRINT ("See the comments in myEXRAIL_Courses_200_Macros.h  AUTOMATION(207) for more information.")
   PRINT ("")
   PRINT ("Enhanced EXRAIL Automated Throttle Control Modified by KC Smith & Rico Landman October 8, 2022")
   PRINT ("1st Loco Leaves Station A to mid Track B & Stops")
   PRINT ("2nd Engine on midTrack A Moves to Station A & Stops")
   PRINT ("3rd Loco Leaves Station B to mid Track A & Stops")
   PRINT ("Rinse & Repeat")
   PRINT ("")
 RESERVE(1) PRINT("RESERVED BLOCK 1")
 RESERVE(3) PRINT("RESERVED BLOCK 3")
 RESERVE(4) PRINT("RESERVED BLOCK 4")
 SETLOCO(1204) FON(0) SENDLOCO(1204, 12) PRINT("SETLOCO(1204)  FON(0) SENDLOCO(1204, 12)")
 SETLOCO(1224) FON(0) SENDLOCO(1224, 43) PRINT("SETLOCO(1224)  FON(0) SENDLOCO(1224, 43)")
 SETLOCO(1225) FON(0) SENDLOCO(1225, 31) PRINT("SETLOCO(1225)  FON(0) SENDLOCO(1225, 31)")
  PRINT("")
  PRINT("PAUSE is On. You Must </RESUME> to start the Automation 207 Three Loco Rico Shuffle !!!")
 PAUSE // Wait Here until the RESUME button is pressed

 POWERON       // Power All Tracks ON
   FON(0)      // Headlight On
   DELAY(100)
   PRINT ("F2 Whistle or Horn immediately to Acknowledge Acquired")
   FON(2)      // Sound Whistle/Horn 
   DELAY(500)  // wait .5 sec 
   FOFF(2)     // Whistle/Horn  Off
   PRINT("")

// From Block 1 to Block 2   {Sns22} > {Sns25}
 SEQUENCE(12)
  RESERVE(2)PRINT("Reserver Block 2, Move to Mid Track B {Sns25} & Stop")
  DELAYRANDOM(2000,4000)    // random wait between 2 and 4 seconds
  FON(2) DELAY(250) FOFF(2) //Short Whistle/Horn
  DELAY(500)
  FWD(30)
  AT(25)      // Sensor S25 == Block BK2
  DELAY(500)
  STOP
  FREE(1)
  DELAY(5000)
  FOLLOW(24)  // follows sequence 24 again forever
 

// From Block 4 to Block 1  {Sns24} > {Sns22}
 SEQUENCE(24) 
  RESERVE(1) PRINT("Reserver Block 1, Move to Station A {Sns22} & Stop")
  DELAYRANDOM(2000,5000) // random wait between 2 and 4 seconds
  FON(2) DELAY(250)FOFF(2)
  DELAY(500)
  REV(32)
  AT(22)      // Sensor S22 == Block BK1
  DELAY(800)
  STOP
  DELAY(5000)
  FREE(4)
  FOLLOW(43)  // follows sequence 43 again forever
 

// From Block 3 to Block 4  {Sns23} > {Sns24}
 SEQUENCE(43)
  RESERVE(4) PRINT("Reserver Block 4, Move to Mid Track A {Sns24} & Stop")
  DELAYRANDOM(2000,4000) // random wait between 2 and 4 seconds
  FON(2) DELAY(250)FOFF(2)
  DELAY(500)
  REV(35)
  AT(24)     // Sensor S24 == Block BK4
  DELAY(650) 
  STOP
  DELAY(5000)
  FREE(3)
  FOLLOW(31) // follows sequence 31 again forever
 


// From Block 2 to Block 3   {Sns2} > {Sns23}
 SEQUENCE(31)
  RESERVE(3) PRINT("Reserver Block 3, Move to Station B {Sns23} & Stop")
  DELAYRANDOM(2000,4000) // random wait between 2 and 4 seconds
  FON(2) DELAY(250)FOFF(2)
  FWD(30)
  AT(23)     // Sensor S23 == Block BK3
  DELAY(500)
  STOP
  DELAY(5000)
  FREE(2)
  FOLLOW(12) // follows sequence 12 again forever
 

IF(217) FOLLOW(807) ENDIF  // loop 807 until 217 is unlatched then Park at Station A and Print & done
   PRINT("Ready to run Next Automation {Handoff} or a Route{Set} button & Manually Drive an Engine")
   PRINT("Or, Press 'EXRAIL 207' Three Loco Rico Shuffle' to run it again")
   DONE
*/
// ************************** End of Lesson 207 "Three Loco Rico Shuffle" ******************************************** //
// ******************************************************************************************************************* //

   ENDEXRAIL  // marks the end of the EXRAIL program Automation(200)Courses scripts for Now. Can't Wait for more Lessons +
