 /*  
 *************************************************************************************************************************************
 * This mySetup_Course_4.1.h are SETUP commands for a users to copy and uncomment in ther individual mySetup.h file
 *  Designed to run on a Mega DCC-EX v4.1+ EXRAIL Command Station with PCA9685 Servo/Signal board & MCP23017 GPIO extenders
 *  
 *  NOTE; If you intend to use myAutomation.h then you only require the DFPlayer and HCSR04 Ultrasonic Sensor be in this mySetup.h
 *  I'm Also using all of these to pass the Uncommented lines to automatically populate JMRI Tools>Tables> Sensors, Turnouts & Outputs
 *  
 *************************************************************************************************************************************

  mySetup.h
  COPYRIGHT (c) 2013-2016 Gregg E. Berman
  COPYRIGHT (c) 2020 Fred Decker
   and Modified 2021-2022 by Kevin C Smith  10-29-22
  The configuration file for DCC-EX Command Station

 **********************************************************************
*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  NOTE: A Custom Setup file by Kevin C Smith
//
//  DEFINE Custom Attributes
//  Use this for a Mega {D22-D49 & A3-A15 aka D56-D69 pins} with a ESP8266 or ESP01 WiFI device, 
//   NOT for a UNO Without WiF, the UNO pins are from {D0 to D19}
//  Additional Virtual pins are added with the PCA9685 Servo/Signal & MCP23017 GPIO expansion boards
//
//  Intended as Samples to help you better understand the use of Pins on a Arduino Mega And Vpins on Accessory boards
//  Most of these Can be setup in your myAutomation.h file instead, If you have created one
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// A List of Setup commands are provided below for you to use by Uncommenting (deleting) the double hash marks
// in front of the SETUP command, but leave the comment // double hash marks After the ; Setup command.

// DCC++EX Commands and CS Diagnostics

 // SETUP("<      >");   // open for user defined command
 // SETUP("<1 MAIN>");   // start with Main track power on. Just a "1" would turn both tracks on
 // SETUP("<1 PROG>");   // start with Prog track power on. Just a "1" would turn both tracks on
 // SETUP("<1 JOIN>");   // Insulated PROG track Joined to Main DCC{PSM} Wave form for Testing CV changes & "Driving Away" onto the mainline     
 // SETUP("<D ACK ON>"); // turn on Prog track ACK diagnostics
 
// DCC++EX uS is currently set from MIN 2000 to MAX 20000 You can change these to Test  your stubborn to read decoders
 // SETUP("<D ACK MIN 2000>");  // Lowered the Minimum Acknowledgement range to xxxx uS
 // SETUP("<D ACK MAX 20000>"); // Raised the Upper Acknowledgement range to xxxxx uS to allow pulses up to 20000 microseconds long,
                                // to Accommodate Decoders QSI =12500uS, & Paragon2/3 =13500uS, and for MTH Decoders =19500uS
 // SETUP("<D ACK LIMIT 60>");  // Override Std default of ackLimitmA = 60 by tuning it with 30 to 100 to try and improve CV reads
                                // 122 660 305 = 12.2 x 25  for ACS724 0-10A 400mv/A
 // SETUP("<D CMD 1>");         // Set Command CMD Off
 // SETUP("<D WIT 1>");         // Set Diagnostics WiThrottle ON=1, OFF=0. Comment Out // to not Start it
 // SETUP("<D WIFI 1>");        // Set Diagnostics WiFI ON=1, OFF=0

// Display Messages on LCD 16x2 Or a OLED 128x32 or a 128x64 screen, must also have their #define set up in your config.h file.
// note; change config.h address depending on the device the PCF8574 are addresses 0x20-0x27, but the NXP PCF8574A is 0x38-0x3f
//  LCD(0 thru 5 are normally reserved for the Command Station reports, but you can use them if you wish
// Send a Message Directly to a LCD or OLED screen lines 6 thru 7
 // LCD(4,F("Used for IP"));     // Is Reserved for IP Address and LCD(5) Was Port# In the WifiInterface.cpp tab about on lines 313 and 317
 // LCD(5,F("Used for Port#"));  // line 5 Detail Firmware Version Info. NOTE Instead See LCD5 used in WiFiInterface.cpp line 313
 // LCD(6,F("myEXRAIL_Courses 9-24-22")); // Line 6 Detailed User Information Version
 // LCD(7,F("mySetup by KC Smith"));      // Line 7 mySetup.h built by whom
 // LCD(7,F("SCMRRC Stoney Creek Model Railroad Club")); // line 7 message 'MRR Club' sent to the LCD display

// Special Serial Data Communication connections
    Serial1.begin(9600);   // set Serial1 {Tx1 Rx1 D18 D19} to   9600 baud to communicate with device like a DFPlayer mini MP3 Sound Module
 // Serial2.begin(115200); // set Serial2 {Tx2 Rx2 D16 D17} to 115200 baud to communicate with JDY-30 BT device like a Bluetooth HC-06 Module
 // Serial3.begin(115200); // set Serial3 {Tx3 Rx3 D14 D15) to 115200 baud Currently used for WiFi Connections on Tx3 Rx3

// Layout Sensor, Turnout & Output EEPROM loading
// Set SENSORS pin 22 23 24 25 26 27 high Pullup
   SETUP("<S 22 22 1>");  // Infrared Or Optical Sensor {Sns22} on pin 22 Point 1 STA {Block1}
   SETUP("<S 23 23 1>");  // Infrared Or Optical Sensor {Sns23} on pin 23 Point 2 STB {Block2}
   SETUP("<S 24 24 1>");  // Infrared Or Optical Sensor {Sns24} on pin 24 Track A T2 {Block4}
   SETUP("<S 25 25 1>");  // Infrared Or Optical Sensor {Sns25} on pin 25 Track A T1 {Block4}
   SETUP("<S 26 26 1>");  // Infrared Or Optical Sensor {Sns26} on pin 26 Track B T1 {Block2}
   SETUP("<S 27 27 1>");  // Infrared Or Optical Sensor {Sns27} on pin 27 Track B T2 {Block2}

    
 ///////// TURNOUTS for Servos connected through a PCA9685 Servo / Signal Control board. //////////////////////////////
 
 // Use SETUP Here or consider setting up Servos & Signals in myAUTOMATION.h INSTEAD
 // Use <T 1 0|1> command to Throw or Close Turnouts
 // For PCA9685 address range 0x40 - 0x46, The First board = 0x40, Second board = 0x41 with pad soldered The PCA
 // HAL will Automatically find the Address and attach it to the Command Station 
 // The First PCA9685 boards Vpins 100-115 and the Second boards Vpins 117-131 
 // Adjust the active_angle, inactive_angle, to Your turnouts/points specific angles
 // Testing the servo from the Serial Monitor command line, enter the command <D SERVO 100 110> & <D SERVO 100 490>. 
 // The servo should move, as long as it isn’t already in that position.
 // Turnout,n,SERVO,vpin, thrownPos, closedPos, Speed 1-4 Fast, Medium, Slow & Bounce
 /* SETUP("<T 1-7 SERVO 100-107 000 000 3>") // set the first eight T0-T7  on Vpin 100-107 available for a total of 8 Servos and reserve the remaining eight 108-115 for signals
    SETUP("<T 0 SERVO 100 490 110 3>"); // Testing Turnout 0 on Servo vpin 100, angle 490 to 110, Slow 3 motion 
    SETUP("<T 1 SERVO 101 300 205 3>"); // Turnout 1 on Servo vpin 101, angle 300 to 205, Slow 3 motion
    SETUP("<T 2 SERVO 102 300 205 3>"); // Turnout 2 on Servo vpin 102, angle 300 to 205, Slow 3 motion
    SETUP("<T 3 SERVO 103 300 205 3>"); // Turnout 3 on Servo vpin 103, angle 300 to 205, Slow 3 motion
    SETUP("<T 4 SERVO 104 300 205 3>"); // Turnout 4 on Servo vpin 104, angle 300 to 205, Slow 3 motion
    SETUP("<T 5 SERVO 105 490 110 3>"); // Accessory Servo 5 on vpin 105 angle 490 to 110, Slow 3 motion

// The T command Above is for Servos for T1 to T4.  Use SERVO 0 for Testing and Servo 5 For a Walking Railfan
*/

// Use SETUP Here or consider setting up these Special FX Effect & Signals in myAutomation.h INSTEAD see myEXRAIL_Couses_100_Macros.h
// Special Lighting and Signal Effects with PCA9685 board and the FADE commands which can be used in the EXRAIL Scripts for AUTOMATION(n) & Routes(n)& SEQUENCES(m)
// FADE("<Vpin, Brightness, Duration>") // Vip 106-115, Bright from 0-4095, Duration=0 Instant, 1=Fast, 2= Medium, 3= Slow, 4= Bounce 
// SETUP("<FADE 108-115, 0000, 0000>"); // FADE("<Vpin, Brightness, Duration>") up to T15 and Vpin 108-115 available for a total of 8 LED Signals
// sample  SETUP("<FADE 113, 1000, 1500>"); // Vpin 113 LED on at 1000 out of  4095 for 1.5 Seconds
// Use SETUP Here or consider setting them up in myAUTOMATION.h INSTEAD
/*  SETUP("<FADE 106, 0000, 0>"); // Vpin 106 Use for a positive lead on a Red LED set to Bright Off 0, ad Durration 0  for Turnout 1 on vpin 101
    SETUP("<FADE 107, 0000, 0>"); // Vpin 107 Use for a positive lead on a Green LED set to Bright Off 0, ad Durration 0  for Turnout 1 on vpin 101
    SETUP("<FADE 108, 0000, 0>"); // Vpin 108 Use for a positive lead on a Red LED set to Bright Off 0, ad Durration 0  for Turnout 2 on vpin 102
    SETUP("<FADE 109, 0000, 0>"); // Vpin 109 Use for a positive lead on a Green LED set to Bright Off 0, ad Durration 0  for Turnout 2 on vpin 102
    SETUP("<FADE 110, 0000, 0>"); //  "
    SETUP("<FADE 111, 0000, 0>"); //  "
    SETUP("<FADE 112, 0000, 0>"); // Vpin 112 White LED used in EXRAIL SEQUENCE(822) as a FX Arc Welder
    SETUP("<FADE 113, 0000, 0>"); // Vpin 113 Blue LED used in EXRAIL SEQUENCE(822) as a FX Arc Welder
    SETUP("<FADE 114, 0000, 0>"); // Vpin 114 RED LED used in EXRAIL SEQUENCE(823) as a FX Camp Fire
                                  // Vpin 114 for Example a RED LED used in EXRAIL SEQUENCE(100)as a FX Caution Signal
    SETUP("<FADE 115, 0000, 0>"); // Vpin 115 for Example a RED LED used in EXRAIL SEQUENCE(101)as a FX Caution Signal
*/

////////////  Additional Optional Accesssory device Setups ////////////////////////////////////////////////////////////////////////////
/* 
 *  Additional User Defined DCC Decoder for Accessory and Ancillary Device Connections. Please See the DCC-EX Website for more detail.
   'DCC Accessories'
    LEGACY <a linear_address 1|0> an Accessory Decoder linear 1-2044 address On or OFF
    LEGACY <a addr subaddr 1|0>   an Accessory Decoder address 0-511 & sub 0-3 address On or OFF
    New DCC <a linear_address 1|0>an Accessory Decoder linear 1-2044 address On or OFF
    New DCC <a addr subaddr 1|0>  an Accessory Decoder address 0-511 & sub 0-3 address On or OFF 
*/

// On UNO Only, Two Reserved System Utility Analog pins A0 & A5 {aka D18 & D19} are used for I2C bus,
//   IF it's turned on for OLED Displays and for PCA9685 Servo Signal Boards.
//  "DO NOT USE for Accessory or Buttons"
// These two are Used on the UNO board for SDA & SCL,  I2C bus connecting HAL devices, and if LCD & OLED are turned on
 // SETUP("<Z 18 18 1>");  // A4 uses Output SDA pin18 for I2C bus for PCA9685 Servo or MCP23017 GPIO extenders
 // SETUP("<Z 19 19 1>");  // A5 uses Output SCL pin19 for I2C bus       "                ""
 
// Mega Optional Mimic Panel Buttons directly connected to the CS, Dpin to Gnd
//  The command station can use a Mega Dpin, Or a Vpin on a Accessory board for buttons as Output pin and then a Gnd pin.
//  Sample< Z 1 31 0>  // create Turnout button 1, on D31,  Then a <T 1 1> will will Throw or Diverge a turnout on pin 31 of an Arduino 
    SETUP("<Z 30 30 0>");  // Open - Use <T 30 0|1> command to Throw=1 or Close=0 Device 0 on pin 30
    SETUP("<Z 31 31 0>");  // Button for Turnout 1
    SETUP("<Z 32 32 0>");  // Button for Turnout 2
    SETUP("<Z 33 33 0>");  //   "          "     3
    SETUP("<Z 34 34 0>");  //   "          "
    SETUP("<Z 35 35 0>");  //  Accessory Servo 5 Walking Person Button

// Mega Setup as ANALOG pins used for accessories Dpin to Input or Output to Gnd
//  SETUP("<a 40-49 available>"); // Pick Either Analog OR Digital
 // SETUP("<a 40 0 0>");
 // SETUP("<a 41 1 0>");
 // SETUP("<a 42 2 0>");
 // SETUP("<a 43 3 0>");
 
// Mega Setup as Analog pins used for accessories Dpin to Input or Output to Gnd
//  SETUP("<a 40-49 available>"); // Pick Either Digital OR Analog                            
// Setup HC-SR04 Ultrasonic Sensor in myHAL.cpp Virtual Vpin=2000, TRIG=40 and ECO=41 i.e., Mega D40 & D41. See myHAL.cpp file 
    SETUP("<a 40 40 1>");  // HC-SR04 1st Sonic Sensor Arduino pin connected to TRIG=40  Shared with 1st & 2nd Sensors
    SETUP("<a 41 41 1>");  // HC-SR04 1st Sonic Sensor Arduino pin connected to ECHO=41
 // SETUP("<a 42 42 1>");  // HC-SR04 2nd Sonic Sensor Arduino pin connected to ECHO=42
 // SETUP("<a 43 43 1>");
 // SETUP("<a 44 44 1>");
 
// TESTING Setup for DFPlayer mini Micro-SD card port IO1 J1 {Previous & Vol-} and IO2 J3 {Next & Vol+
 // SETUP("<Z 45 45 1>");   // Mega Dpin 45 to DFPlayer IO1 {Prev & Vol- long press}
 // SETUP("<Z 46 46 1>");   // Mega Dpin 45 to DFPlayer IO2 {Next & Vol+ long press}
 // SETUP("<Z 47 47 1>");
 // SETUP("<Z 48 48 1>");
 // SETUP("<Z 49 49 1>");
    
// Four MEGA Special System Utility SPI bus pins are  D50=MISO, D51=MOSI, D52=SCK, and D53=SS. "DO NOT use for Servos or Buttons"
//  SPI bus is normally use to communicate between station 
 //  SETUP("<Z 50 50 1>");  // Use this Output pin to signal MISO
 //  SETUP("<Z 51 51 1>");  // Use This Output pin to signal MOSI
 //  SETUP("<Z 52 52 1>");  // Use this Output pin to signal SCK 
 //  SETUP("<Z 53 53 1>");  // Use This Output pin to signal SS
 
// On MEGA the Two Reserved System Utility Analog pins A0 & A1 {aka D54 & D55} are used for Main & Prog Track Current Sensing
//  "Do Not use pins A0 & A1 aka 54 & 55" for anything else
// Use the Other available MEGA Analog pins A3-A15 {aka D56-D69}

// For Special calls Like two Output pins for Signaling and Lighting Effects or Accessory Board interface.
// SETUP("<Z 60 through 69 set to be High 1 or Low 0>") are Mega Analog GPIO pins A6 - A15 Analog aka D60-D69 Digital Pins
 // SETUP("<Z 60 60 1>");  // A6 use this Output pin D60 to signal Accessory to trigger a event, Like turning On & Off devices
 // SETUP("<Z 61 61 1>");  // A7 use This Output pin D61 to signal "
 // SETUP("<Z 62 62 1>");  // A8 use this Output pin D62 to signal "
 // SETUP("<Z 63 63 1>");  // A9 use This Output pin D63 to signal "
 // SETUP("<Z 64 64 1>");  // A10 use this Output pin D64 to signal "
 // SETUP("<Z 65 65 1>");  // A11 use This Output pin d65 to signal "
 
// New Command Line ANALOG D Vpin addressable for any Arduino pin to set High or Low with a T command <T 66 1|0> On | Off
/*
  //SETUP <D ANIN vpin> and <D ANOUT vpin value> 
    SETUP("<D 66 VPIN 66>"); // A12 Analog Vpin 66 
    SETUP("<D 67 VPIN 67>"); // A13 Analog Vpin 67 
    SETUP("<D 68 VPIN 68>"); // A14 Analog Vpin 68 
    SETUP("<D 69 VPIN 69>"); // A15 Analog Vpin 69 
 */
 
// Setup First PCA9685 Signal Vpin 100-115 Available But may already be used Above by a Servo or Signal or in myAutomation.h file 
// NOTE; The PCA boards have Special FADE LED Lighting like Arc Welder etc., which Other GPIO boards do Not
//  SETUP("<Z Vpin Vpin 0|1>") // pin 100-115 available with 0 Low|Off, and 1 High|On
 // SETUP("<Z 100 100 0>"); //  Testing Servo Turnouts and Animated Accessories 
 // SETUP("<Z 101 101 0>"); //  Servo Station A Turnout T1
 // SETUP("<Z 102 102 0>"); //  Servo Station B Turnout T2
 // SETUP("<Z 103 103 0>"); //  Servo Turnout T3
 // SETUP("<Z 104 104 0>"); //  Servo Turnout T4
 // SETUP("<Z 105 105 0>"); //  Accessory Servo Used for a slow motion action - Railfan Walking
 // SETUP("<Z 106 106 0>"); // Red   point signal for turnout T1
 // SETUP("<Z 107 107 0>"); // Green point signal for turnout T1
 // SETUP("<Z 108 108 0>"); // Red     "     "          "     T2
 // SETUP("<Z 109 109 0>"); // Green   "     "          "     T2
 // SETUP("<Z 110 110 0>"); // Red                            T3
 // SETUP("<Z 111 111 0>"); // Green                          T3
    SETUP("<Z 112 112 0>"); // Arc Welder uses vpin112 White LED,
    SETUP("<Z 113 113 0>"); // Arc Welder uses Vpin113 Blue LED
    SETUP("<Z 114 114 0>"); // Caution or Crossing Signals, And Campfire use only vpin114 Red or Amber LED
    SETUP("<Z 115 115 0>"); // Caution or Crossing Signals

// Additional HAL MCP23017 GPIO Expander Boards, HAL will Automatically find first two Addresses and attach them to the Command Station 
//  'DCC Accessories' Note for GPIO Expansion boards, like MCP23017 have adresses 0x20-0x27, with Vpin values from 164-178 and vpins 179-193
// SETUP("<Z Vpin Vpin 0|1>") // Up to pin 164-178 available with 0 Low|Off, and 1 High|On
 // SETUP("<Z 164 164 0>"); // Open GPIO Pins
 // SETUP("<Z 165 165 0>"); // Red   point signal for turnout
 // SETUP("<Z 166 166 0>"); // Green point signal for turnout
 // SETUP("<Z 167 167 0>");
 // SETUP("<Z 168 168 0>"); 
 // SETUP("<Z 169 169 0>");
 // SETUP("<Z 170 170 0>");
 // SETUP("<Z 171 171 0>");
 // SETUP("<Z 172 172 0>");
 // SETUP("<Z 173 173 0>");
 // SETUP("<Z 174 174 0>");
 // SETUP("<Z 175 175 0>");
 // SETUP("<Z 176 176 0>");
 // SETUP("<Z 177 177 0>");
 // SETUP("<Z 178 178 0>");


 ///////////////////////////////////////////////////////////////////////////////////////////////////
// Additional Special HAL 'Hardware Abstract Layer' Devices  See myHAL.cpp file for #define detail
////////////////////////////////////////////////////////////////////////////////////////////////////
// DFPLAYER MP3 TF SDmicro card
// Example on the Mega Dpins TX1(18)/RX1(19) which is Serial 1. 
//  Connect the DFPlayer’s RX to the Arduino TX1(18) via a 1kOhm resistor, and DFPlayer’s TX direct to the Ardino RX1(19). 
//  You also need to connect +5V power to VCC, and GND on the Arduino to GND on the DFPlayer.
//  Connect a small speaker to the pins SPK1 and SPK2 on the DFPlayer, and that’s the hardware set up.
// The five Virtual VPINs, 1000 to 1004, allow the first five MP3 files on the Micro-SD card to be played directly.
//  You just need to write to the pins as if they were real digital output pins on the Arduino.
// For example, set up some outputs using the Arduino IDE’s serial monitor program, by entering the following commands:
/*
  SETUP("<Z 1000 1000 0>"); // Accessory to trigger a event, Like turning On & Off and 1st file on a MP3 Player Sound board
  SETUP("<Z 1001 1001 0>"); // Accessory to trigger a event, Like play 2nd file on a MP3 Player Sound board
  SETUP("<Z 1002 1002 0>"); // Accessory to trigger a event, Like play 3rd file on a MP3 Player Sound board
  SETUP("<Z 1003 1003 0>");
  SETUP("<Z 1004 1004 0>");
*/
 
// Actual EXRAIL SEQUENCE(1500)sample using a DFPLAYER defined in myHal.cpp on vpin1500
//  Connect the DFPlayer’s RX to the Arduino Tx1(18) via a 1k Ohm resistor, and DFPlayer’s TX direct to the Ardino Rx1(19). 
//  You also need to connect Mega +5V power to DFPLAYER VCC, and Mega GND to the GND on the DFPlayer.
//  Connect a small speaker to the pins SPK1 and SPK2 on the DFPlayer, and that’s the hardware set up.
//  Then Setup a DFPLAYER in myHAL.cpp on Virtual vpin1500 and 1st sound file on vpin1500 & 2nd sound file on 1501
//  And #define the serial port you want to use, We'll use serial 1 one from inside the config.h file.
// DO NOT define any accessory serial port as the same one your using for Tx Rx WiFI or the WiFi will Not work 

// Actually Setup a DFPLAYER in myHAL.cpp on Virtual vpin=1500 and sound on vpins 1500, 1501 & 1502 See myHAL.cpp file  
   SETUP("<Z 1500 1500 0>"); // Accessory to trigger a event, Like turning On & Off & Play 1st file on a DFPlayer MP3 card
   SETUP("<Z 1501 1501 0>"); // Accessory to trigger a event, Like play 2nd file on a DFPlayer MP3
   SETUP("<Z 1502 1502 0>"); // Accessory to trigger a event, Like play 3rd file on a DFPlayer MP3
   SETUP("<Z 1503 1503 0>"); // Accessory to trigger a event, Like play 4th file on a DFPlayer MP3
   SETUP("<Z 1504 1504 0>"); // Accessory to trigger a event, Like play 5th file on a DFPlayer MP3
   SETUP("<Z 1505 1505 0>"); // Accessory to trigger a event, Like play 6th file on a DFPlayer MP3
   SETUP("<Z 1506 1506 0>"); // Accessory to trigger a event, Like play 7th file on a DFPlayer MP3
   SETUP("<Z 1507 1507 0>"); // Accessory to trigger a event, Like play 8th file on a DFPlayer MP3
   SETUP("<Z 1508 1508 0>"); // Accessory to trigger a event, Like play 9th file on a DFPlayer MP3
   SETUP("<Z 1509 1509 0>"); // Accessory to trigger a event, Like play 10th file on a DFPlayer MP3
   SETUP("<Z 1510 1510 0>"); // Accessory to trigger a event, Like play 11th file on a DFPlayer MP3
   SETUP("<Z 1511 1511 0>"); // Accessory to trigger a event, Like play 12th file on a DFPlayer MP3
   SETUP("<Z 1512 1512 0>"); // Accessory to trigger a event, Like play 13th file on a DFPlayer MP3
   SETUP("<Z 1513 1513 0>"); // Accessory to trigger a event, Like play 14th file on a DFPlayer MP3
   SETUP("<Z 1514 1514 0>"); // Accessory to trigger a event, Like play 15th file on a DFPlayer MP3


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
// *** Special Hardware TrackManager settings DCC_EX Version 5.0 *** Pending Release
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

// For Future TrackManagerTM version 5.0 See the Pre-Relese Test branch PORTX-HAL version 4.2.4 and up, On Mega2560
//  If you want to set them up in mySetup.h Instead of in myAutomation.h then use the SETUP<= >commands below.
//  Command Station TrackManager DCC & DC district tracks from A-H, the default is A Main and B Prog 
// Available Waveforms Modes are;
//   MAIN & PROG for DCC{PWM}
//   DC & DCX    for DC{PWM} 
//   and OFF
//
// Command Station Districts TrackManager PowerChannels A-H default is A Main and B Prog
// Format SETUP(set, track, mode)
//  Alternate CS Districts instead of the Defautt A "Main" and B "Prog"
  // SETUP("<= A PROG>");  // DCC on Prog A Track the Opposite of CS Defaults
  // SETUP("<= B MAIN>");  // DCC on Main B Track with any DCC address from 1-10239``
// Or
  // SETUP("<= A MAIN>");   // Both Main, Use A for Trains and B for Layout
  // SETUP("<= B MAIN>");   // Accessories like Turnouts and DCC Accy Decoders 
                                        
//  Or Else Mixed
// Format SETUP(set, track, mode, address) for Valid DC Track Addresses are 1 thru 10239,
  // SETUP("<= A DC 1>");  // DC on A for Primary Legacy DC Track with address 1 or CAB 1
  // SETUP("<= B DC 2>");  // DC on B for Secondary Legacy DC Track with Address 2 or CAB 2
 
//  Or Both DC
  // SETUP("<= A DC 3>");  // Dual DC on A and B for Legacy Analog Layout
  // SETUP("<= B DC 3>");  // Runnnng CAB 4 across multiple blocks
//  Or
  // SETUP("<= B DCX 3>"); // DC on B but with Opposite Polarity on Rail L+ R-  NMRA Modular Standard for B Track
  // SETUP("<=>");         // Show current TrackManager Mode the CS is set to

// End mySetup.h   
