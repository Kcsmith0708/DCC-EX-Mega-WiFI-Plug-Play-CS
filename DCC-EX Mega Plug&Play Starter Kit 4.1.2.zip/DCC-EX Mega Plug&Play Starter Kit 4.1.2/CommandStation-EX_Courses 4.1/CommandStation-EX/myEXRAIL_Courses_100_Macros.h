/*
 ***********************************************************************************************************************
 * This is "myEXRAIL_Courses_100_Macros.h" EXRAIL Setup Command Station Startup & Layout Accessories   August 22, 2022
 *  Designed to run on a Mega DCC-EX v4.1+  Mega DCC-EX EXRAIL Command Station
 ***********************************************************************************************************************
 ********************* By Kevin C Smith, DCC-EX Dev Team and a SCMRRC member  ******************************************
 * 
 *  This "myEXRAIL_Courses_100_Macros.h" automation file requires DCC++EX 4.1.2 release or higher
 *   and can be used by renaming your current myAutomation.h file to something else like myAutomation_Initials.h
 *     then simple copy & rename myAutomation_Courses.h to myAutomation.h and it already includes this 
 *       #include "myEXRAIL_Courses_100_Macros.h"
 *       
 *   Then Recompile and uploade to a Mega + WiFi Command Station with a PCA9685 Servo Signal board & 9G Servos
 *    to Automatically run these Macros & Automation Scripts
 *      
 *   It is designed to run with a example layout 'Example EXRAIL Automation' Station A to Station B 
 *     Which Includes many Accesories samples;
 *       Two Servo_Turnouts with Red/Green LED point signals, a Animated Accessory Servo & Special FX Effects for 
 *        Railfan Walking, FX Arc Welder, FX Campfire, FX Caution Signals & Lighting, DFPlayer MP3 Sound card,
 *       and runs many EXRAIL Automation, Route & Sequences from Station A to Station B on two tracks A & B.
 *
 *    Note; Command Station Setup.
 *    Assumes a working DCC-EX MEGA + WiFi ready Command Station configuration,{NOT a UNO Command Station}
 *    DCC-EX Command Station V4.1.2 Master or greater.
 *    Arduino Mega 2560 micro controller or clone equivalent with a 7-9Vdc center positve power supply
 *    Arduino or Deek Robot L298P Motor Shield with {Vin Cut} and a 12-16Vdc center positive power supply 
 *    MakerFab ESP8266 Or a ESP01 board with ESP8266 WiFi compatable device
 *    Accessories;
 *     Four Infrared Sensors Sns22, Sns23, Sns24, & Sns25 in Mega Dpins 22,23,24 & 25
 *     One PCA9685 Servo/Signal board wired from {SCL, SDA, VCC, Gnd} to the Motor Shield {SCL, SDA, 5V, Gnd} Male pins
 *     Three 9gram Servo Turnouts connected on PCA9685 Vpins 101, 102, & 105 with three pin connector on Output, 5v, Gnd
 *     Red\Green LEDs Point Signals connected on PCA9685 Vpins Red 106 & 108, and Green 107 & 109 with two pins Output & Gnd
 *     One White, One Blue LEDs 'FX Arc Welder' on PCA9685 Vpins 112 & 113 with two pins Output & Gnd
 *     One Red or Yellow LED 'FX Campfire' on PCA9685 Vpins 114 with two pins Output & Gnd
 *     Two Red or Yellow LEDs 'FX Caution or Crossing Signal' on the PCA9685 Vpin 114 & 115 on pins Output & Gnd
 *   Adjust the Servo Angles to fit your Point throw distances separately before using them in this script.
 *    
 *    Bonus Accessories Setup in myHal.cpp
 *     One DFPlayer mini MP3 Micro-SD Sound Card setup on Serial l Tx1 Rx1 {D18, D19} and 15 sound files on Vpins 1500-1514
 *     One HCSR04 Ultrasonic Sensor setup as Vpin2000 and with Mega pins D40=TRIG , D41=ECHO
 *     
 **************************************************************************************************************************  
 * Acknowledgement; DCC-EX Software Created by Chris Harlow, Harald Barth, Neil McKechnie, Fred Decker & DCC-EX Dev Team 
 **************************************************************************************************************************
 *  The presence of a file called "myAutomation.h" brings EX-RAIL code into the command station.
 *  The automation may have multiple concurrent setup procedures and tasks. 
 *  A task may be
 *  
 * EXRAIL Sample
 * Macros for Rosters, Alias, Servo Turnouts & Signals, Special Accessory Servo movement & Special FX Lighting Effects.   
 * And Train Control AUTOMATION(n), ROUTE(n) & SEQUENCE(n) Scripts
 *
 *  A AUTOMATION, Route or SEQUENCE are internally identical in EX-Rail terms  
 *  but are just represented differently to a WiThrottle user:
 *  ROUTE(n,"name") - as Route_n .. to setup a route through a layout
 *  AUTOMATION(n,"name") as Auto_n .. to send the current loco off along an automated journey
 *  SEQUENCE(n) is not visible to WiThrottle.
 */
 
//|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
// Please be sure your DCC-EX Command Station and your WiFi Throttles are connected to the same local WiFi name      ||
// Your WiFi Router Station STA mode to SSID 'Name' & 'Password'                                                     ||
//  Or in this DCCEX Command Stations direct Access Point AP mode to DCCEX_"xxxxxx" & PASS_"xxxxxx"                  ||
//  See your config.h and edit the WiFi settings as needed                                                           ||
//|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

 // The following sample Commands & Scripts can be used in your user defined "myAutomation.h" file
 // They must be copied to and present inside your CommandStation-EX Folder first before they can be used.
 // These must have a DONE at the end of a list of startup macros or the scripts Below them will automatically start.
 
// ***************************************************************************************************************** //
// This "myEXRAIL_Courses_100_Macros.h" includes Lessons 100-106 Setup Command Station Startup & Layout Accessories
//  For additional Lessons 201-205 Control Automation & Trains with Engine Driver see "myEXRAIL_Courses_200_Macros.h"
// ***************************************************************************************************************** //

// ***************************************************************************************************************** //
 // Optionally Include and call additional "myEXRAIL_.h" setup scripts into your main "myAutomation.h" file
 //   #include "myEXRAIL_Courses_100_Macros.h" // Lessons 100 Setup Command Station Startup & Layout Accessories
 //   #include "myEXRAIL_Courses_200_Macros.h" // Lessons 200 Samples to Control Automation & Trains with Engine Driver     
 //   #include "myDCCEX_CommandSummary4.1.h"      // Bonus DCC-EX Command Summary Lists on IDE Serial Monitor Display
 //   additional "myEXRAIL_something.h"        // Your individual myEXRAIL_.h files
// ***************************************************************************************************************** //

// Lets begin with EXRAIL Courses Lessons 101 - 105 Creating Roster, Servos, Turnouts, Signals & Throttle Cmd buttons.
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 // Setup macros on your Mega Command Station and in your Engine Driver & WiThrottle App below, Includes;
 // Lesson 101 Roster only a sample how to build a Roster for Directly connected WiFi Throttles to a DCC-EX CS
 // Lesson 102 Roster, Alias, LCD/OLED, Command Station Bootup, Servo_Turnouts & Signal Red\Green LED Point Setup
 // Lesson 103 Create Turnouts ONCLOSE & ONTHROW functions 
 //            Create Routes on Track A and Track B between Station A & B
 //            Bonus Special Effect FX macros
 //             Accy Servo for Railfan Walking
 //             Caution Signal
 //             Arc Welder
 //             Campfire
 //             Clear FX Devices & Lighting
 // Lesson 104 Adding Mimic Panel Momentary Push Buttons for Servo Turnouts & Signals.
 //            Create a #define CLEVER command to combine Turnouts, Buttons & Signals into one macro
 // Lesson 105 Engine Driver & WiThrottle Command buttons with Automation {Handoff} & Route {Set}
 //
 // Optional Bonus Special Device macros
 // Lesson 106 DFPlayer mini micro-SD MP3 Sound card automation.
 // Lesson 107 HC-SR04 Ultrasonic Sensor w/ a Blue LED and DFPlayer mini sound card Combination.
 //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// ******************************************************************************************************************** //
// EXRAIL Course Lesson 101 Edit & Create your Roster Engines                                      -- Conductor Level
//  Roster only sample of how to build a Roster for Directly connected WiFi Throttles to a DCC++EX CS
//   Edit These Lesson 101 Roster lines and Created your personal Engine Roster
//   Change the Loco number & Name to your layouts specific Engine i.e. Loco numbers in this Lesson 101 script only.
// *********************************************************************************************************************//

// Edit & Create DCC Engine Rosters for decoders With & Without Sound Then Uncomment your new ROSTER Engine Line
//  {Name Syntax Caps and spaces matter If you want to syncronize with the JMRI Roster}
//   Use *asterisk for function keys that are unlatched i.e. Horn & Whistle         
// EXRAIL Defined Engine ROSTER(dcc_address,"name","F0/F1/*F2/*F3/F4/F5/F6/F7/Mute/etc/")
 //  ROSTER (  3,"Eng 3","F0/F1/*F2/*F3/F4/F5/F6/F7/Mute/F9//")  // Address 3, Eng 3, Function keys F0-F10
 //  ROSTER(1224,"PE 1224","HeadLgt/") // Motor Only Decoder, But uses Engine Driver 'Preferences > 'In Phone Loco Sound'
 //  ROSTER(1225,"PE 1225","Lights/Bell/*Whistle/*Short Whistle/Steam/On-Time/FX6 Bell Whistle/Dim Light/Mute")
 //  ROSTER(4468,"LNER 4468","//Snd On/*Whistle/*Whistle2/Brake/F5 Drain/Coal Shvl/Guard-Squeal/Loaded/Coastng/Injector/Shunt-Door ~Opn-Cls/Couplng/BrakeVlv/Sfty Vlv/Shunting/BrkSql Off/No Momentm/Aux3/Fade Out/F22 Res/F23/Res//Aux 5/Aux6/Aux7/Aux 8")
//
// Practice Note; After you replace the above Roster list to your specific engines, you can uncomment them here 
// Or Copy and move them over to the myAutomation.h file and Paste and Uncomment them in the beginning of that file.
// They will then also Display in your Engine Driver and WiThrottle WiFi Throttles.
// *** You can only have One Uncommented engine with the same 'number' & 'name' at a time in your myAutomation.h
//     and in other files like this myEXRAIL_Courses.h file, or you will get a compile error 'duplicate case value'

//||||||||||||||||||||||||||||||||||||||||||||||||||||||| End of Lesson 101  |||||||||||||||||||||||||||||||||||||||||||||

// *********************************************************************************************************************** //
// EXRAIL Course Lesson 102                                                                           -- Conductor Level
//  This Engine Roster below must be included, 'LEAVE These Engines "As Is" They're used in the example Automation later on'.
//  Create an ALIAS Name for your Automation, Route & Sequence (n) numbers
//  LCD & OLED Display messages
//  Startup Command Station(CS) set Power & Turnout positions
//  Create Servos for 2 or more Turnouts and a Accessory Servos for a Walking Railfan or Bagage Handler or a Crossing Gate
//  Create Red|Green Point Turnout Signals for Turnouts T1 & T2
//  Create Special Lighting Effects for 'FX Caution or Crossing Signals' a 'FX Arc Welder' and a 'FX Campfire'
// *********************************************************************************************************************** //

// DCC Engine Rosters for decoders With & Without Sound {Name Syntax Caps and spaces matter, If you want to syncronize with JMRI Roster}
// EXRAIL Defined Engine ROSTER(dcc_address,"name","F0/F1/*F2/*F3/F4/F5/F6/F7/Mute/etc/") // Use asterisk* for function keys that are unlatched i.e. Horn & Whistle
   ROSTER(   3,"Eng 3","F0/F1/*F2/*F3/F4/F5/F6/F7/Mute/F9/F10/") // Address 3, Eng 3, Function keys F0-F10
   ROSTER(1224,"PE 1224","HeadLgt/") // Motor Only Decoder, But use the Virtual Sound Decoder in Engine Driver 'Preferences> In Phone Loco Sounds' 
   ROSTER(1225,"PE 1225","Lights/Bell/*Whistle/*Short Whistle/Steam/On-Time/FX6 Bell Whistle/Dim Light/Mute/F9/F10/")
   ROSTER(4468,"LNER 4468","Snd On/*Whistle/*Whistle2/Brake/F5 Drain/Coal Shvl/Guard-Squeal/Loaded/Coastng/Injector/Shunt-Door ~Opn-Cls/Couplng/BrakeVlv/Sfty Vlv/Shunting/BrkSql Off/No Momentm/Aux3/Fade Out/F22 Res/F23 Res/F24/Aux 5/Aux6/Aux7/Aux 8")
// ROSTER(4468-2,"LNER 4468-2","Lights/Steam/*L~Whistle/*S~Whistle/*Whistle2/DoorSlam/Whl Slip/Coal Shvl/BlwDown/SftyVlv/Injector/CylnCock/Brake/Blower/Grd Whistle/Coupler/Fireman/Chuff-Coast/Aux Lghts")

/* 
// ****** Roster For Future DCC-EX TrackManager v5.0 Only for DC motor only and DC Enabled DCC decoder motor only engines ****** //
// Legacy Analog DC CAB Roster, {Legacy Analog DC CAB addresses 1 thru 10239} Note; Some throttle only accept 4digits up to 9999
// Note; Functions F1-F3 for Bell, *Horn/Whistle, *Short Whistle & 'Mute' Sounds are available via Engine Drivers 
//       New, In Phone Loco Sounds IPLS See Engine Driver App v2.32.152+ for details on IPLS In Phone Loco Sounds.
// EXRAIL Defined CAB DC ROSTER(address,"name"," ") // One Space for F-Key
 //  ROSTER(   1,"CAB 1"," ")    // Analog DC Motor Only
 //  ROSTER(   2,"CAB 2"," ")    // Analog DC Motor Only 
 //  ROSTER(  24,"PE 024"," ")   // Analog DC Motor Only Trolley
 //  ROSTER( 667,"NH 667"," ")   // Analog DC Motor Only Diesel
 //  ROSTER(1952,"3M 1952"," ")  // Analog DC Motor Only Steam
*/
// *********************************************************************************************************************** //


// *********************************************************************************************************************** //
// EXRAIL Courses Lesson 102 Create an ALIAS Name for your Automation, Route & Sequence (n) numbers   -- Conductor Level
//  ALIAS command assigns a Name and is {Case Sensitive}
//  ALIAS Must come at the beginning Before your User Commands & Automation & Route Scripts
// Special ALIAS NUMBER PARSER. Use <? Cmd_NAME> Command in a Serial monitor to Generate a number assigned to Command Names
//  enter command <? Cmd_JOIN> in the IDE command line and it returns p=27625 
//    Use these to assign and create your ALIAS
// *********************************************************************************************************************** //

// DCC++EX Commands to send to Engine Driver {Set} & WiThrottle {Route} as  Buttons.
// Using an ALIAS
   ALIAS(Cmd_JOIN,27625)
   ALIAS(Cmd_UNJOIN,29548)
   ALIAS(Cmd_PAUSE,22343)
   ALIAS(Cmd_RESUME,32532)
   ALIAS(Cmd_POWERON,29397)
   ALIAS(Cmd_POWEROFF,12741)
   ALIAS(Cmd_SpeedStep_28,14520)
   ALIAS(Cmd_SpeedStep_128,13976)
   ALIAS(Route_Reset_Turnouts,2932)


////////////////////////////////////////////////////////////////
// Command Station Startup Proceedure & LCD & OLED Displays
////////////////////////////////////////////////////////////////
// ****************************************************************************************************************************** //
// EXRAIL Course Lesson 102 LCD 'Liquid Crystal Display' or OLED 'Organic Light Emmiting Diode' Displays      --Conductor Level
// Send a Message Directly to a LCD or OLED screen lines 0 thru 7.
// In config.h Uncomment the device you would like to use.  We are using;  #define OLED_DRIVER 128x32
// Note; Messages will Also display on the Serial monitor in Whole and may be longer than your LCD or OLED Screen width 
// ****************************************************************************************************************************** //
   LCD(5,"Mega+WiFi Plug&Play Starter Kit Setup by KC Smith 10-29-22") // Message to OLED line 5 and to the Serial monitor
   LCD(6,"MyEXRAIL_Courses_Macros.h by KC Smith 10-29-22") // Message to OLED line 6 and to the Serial monitor
   LCD(7,"SCMRRC Stoney Creek Model Railroad Club") 


///////////////////////////////////////////////////////////////////////////////////////
// Command Station Startup Proceedure and Set your Turnouts and Point Signals
///////////////////////////////////////////////////////////////////////////////////////
// EXRAIL Set Turnouts to desired position on Startup also Red/Green LED point signals Sync to Close or Throw On Startup
// Note; On Turnouts, CLOSE representing 0 zero, THROW Represents 1 one.
// Upon initial starting of the Command Station set the Turnouts & Track Power as follows

 ROUTE(Route_Reset_Turnouts, "Route Reset Accy Servos & Turnouts to the Beginning")
  PRINT("")
  PRINT("Reset Accessory Servos & Turnouts to there Starting Positions")
   THROW (0)  // On Command Station start up Set Turnouts & Servos to Starting Positions
   CLOSE (1)  // On Startup Set Turnout 1 to Track B LED Green
   CLOSE (2)  // On Startup Set Turnout 2 to Track B LED Green
   THROW (3)  // On Startup Set Turnout 3 to Track C LED Red
   THROW (4)  // On Startup Set Turnout 4 to Track C LED Red
   CLOSE (5)  // On Startup Set Accessory Servo 5 to Beginning
   DELAY(3500)
   PRINT(" Servo Turnouts T1, T2, T3, T4 & Accessory Servo 5 RESET") PRINT("")
  

////////////////////////////////////////////////////////////////////////////////////////////
// Command Station Power State at Startup ?
///////////////////////////////////////////////////////////////////////////////////////////

 // POWERON  // Uncomment this line to Start Command Station with Power ON to all Tracks
             // Not Recommended

  DONE /* This is the First DONE in myEXRAI_Courses_100_Macros.h and ends the Command Station Startup thread which Sets up
        * Roster Engines that you'll use on the CS with Directly connected WiFi Throttles
        * Alias names for your Sequences and Route names in WiThrottle Apps
        * LCD or OLED devices initial display messages
        * Turnouts and Accessory Servos startup positions
        * leaves the Command Station with the track Power OFF.
        */

//////////////////////////////////////////////////
// Creating Servos Turnouts & a Accessory Servo 
//////////////////////////////////////////////////
// ****************************************************************************************************************************** //
// EXRAIL Course Lesson 102 using SERVO_TURNOUT & SIGNAL commands                                             -- Conductor Level
//  Create Servos for 2 or more Turnouts and Accessory Servos for a Walking Railfan or Bagage Handler or a Crossing Gate
//
// Using a single PCA9685 Servo/Signal Board {SCL, SDA, VCC, Gnd pins}, wired to the Mega or Motor Shield {SCL, SDA, 5v, Gnd pins}
//  AND a separate 5Vdc power supply Pluged into the PCA board + - Blocks
// Plus 9G mini servos & Red|Green LED for Point Signals and two Yellow LED Caution Signal, OR two Red LED Crossing Signals
// ****************************************************************************************************************************** //

// New EXRAIL 4.1 SERVO_TURNOUT command. Allows Servos to be setup & named Here, Instead of in the mySetup.h file
// Set up Servos on vpin 100-105,(on the first PCA9685 board) 
// SERVO_TURNOUT(id,pin,active_angle,inactive_angle,profile,"description")// active_angle -> thrown, inactive_angle -> close
                                                                         // profile Slow, Medium, Fast, Bounce, Optional [description]
   SERVO_TURNOUT(0,100,490,110,Slow,"Testing Servo 0")      // Testing Or Accessory Servo T0 vpin 100, angles 490 to 110, Slow 3 motion
   SERVO_TURNOUT(1,101,400,205,Slow,"Station_A Turnout T1") // Turnout T1 Servo vpin 101, angles 400 to 205, Slow 3 motion 'Description'
   SERVO_TURNOUT(2,102,400,205,Slow,"Station_B Turnout T2") // Turnout T2 Servo vpin 102,            ' 
   SERVO_TURNOUT(3,103,400,205,Slow,"Turnout T3")           // Turnout T3 Servo vpin 103,            '
   SERVO_TURNOUT(4,104,400,205,Slow,"Turnout T4")           // Turnout T4 Servo vpin 104,            '
   SERVO_TURNOUT(5,105,490,110,Slow,"Accessory Servo 5 Railfan") // Accessory Servo T5 vpin 105, angles 490 to 110, Slow 3 motion
                                                                // Servo 5 as a Walking Railfan or Baggage Handler back & forth
                                                               // Or Servo 5 as a Crossing Gate moving up & down
                                                                 
///////////////////////////////////////////////////
// Creating Signals for Servo Turnouts and Masts
///////////////////////////////////////////////////
// Signals setup on vpins 106, 107 ,108, 109, 110, 111, 112, 113, 114, 115(on first PCA9685 Signal Board)
// SIGNAL(red_pin, amber_pin, green_pin) Define a signal (RED/AMBER/GREEN commands 
//  always use the first red_pin as the signal_id for All signal color changes)
   SIGNAL(106, 0, 107) // Red, Amber, Green For Turnout 1
   SIGNAL(108, 0, 109) // Red, Amber, Green For Turnout 2
   SIGNAL(110, 0, 111) // Red, Amber, Green For Turnout 3
   SIGNAL(112, 0, 113) // Red, Amber, Green For Turnout 4, OR Instead use vpins 112 & 113 for Arc Welder effects
   SIGNAL(114, 114, 0) // Red OR Amber LED Caution Signal and Campfire effect > warn Railfan, or Crossing Gate on Accy Servo 5
   SIGNAL(115, 115, 0) // Red OR Amber LED Caution Signal > warn Railfan, or Crossing Gate with Accessory Servo 5
   
// *********************************************************************************************************************** //
// EXRAIL Course Lesson 102 using SERVO_SIGNAL for Turnout Point Signals                              -- Conductor Level
// New 4.1 SERVO_SIGNAL(vpin, redpos, amberpos, greenpos)  // define a Servo Signal
//  Use the first Red vpin# as the signal_id for All Signal color changes
// *********************************************************************************************************************** //
// Instead you can use this to Combine the two commands Signal and Servo_Turnout from above into One Function 
    SERVO_SIGNAL(106, 400, 0, 205) //  Red vpin 106 for Turnout 1, Thrown=Red, Close = Green
    SERVO_SIGNAL(108, 400, 0, 205) //  Red vpin 108 for Turnout 2, Thrown=Red, Close = Green
    SERVO_SIGNAL(110, 400, 0, 205) //  Red vpin 110 for Turnout 3, Thrown=Red, Close = Green
    SERVO_SIGNAL(112, 400, 0, 205) //  Red vpin 110 for Turnout 4, Thrown=Red, Close = Green

// *********************************************************************************************************************** //
// EXRAIL Course Lesson 102 using Macro to Individually  CLOSE & THROW Turnouts                      -- Conductors Level
// *********************************************************************************************************************** //
// Macros for Controlling Individual Turnouts and the Point Signals will automatically follow the turnout

  ONCLOSE (1) DELAY(1000) PRINT ("Close Turnout 1 on Track B, Signal Green")
   GREEN (106)            PRINT ("T1 Closed ~ B GREEN")
   DONE
  ONCLOSE (2) DELAY(1000) PRINT ("Close Turnout 2 on Track B, Signal Green")
   GREEN (108)            PRINT ("T2 Closed ~ B GREEN")
   DONE
  ONCLOSE (3) DELAY(1000)PRINT  ("Close Turnout 3 on Track B, Signal Green")
   GREEN (110)            PRINT ("T3 Closed ~ C GREEN")
   DONE
/* ONCLOSE (4) DELAY(1000) PRINT ("Close Turnout 4 on Track B, Signal Green") // Uncomment Line If you want vpin 112 & 113 as a Turnout
   GREEN (112)            PRINT ("T4 Closed ~ C GREEN")      // later we are going to use vpin112,113 as a FX Arc Welder instead
   DONE

*/
// ACCESSORY TEST SERVO vpin100  Use this for either Testing Servos FX Special Effect lik a Signal Gate
  ONCLOSE(0)      // Set Accessory Servo 0 closed
   DELAY(2000)
   PRINT("Test Servo 0 Position Closed")
   DONE
   
// ACCESSORY SERVO vpin105 
  ONCLOSE(5)      // Set Accessory Servo 5 closed
   DELAY(3000)
 //PRINT("Accessory Servo 5 Closed")
//  Or
   PRINT("Railfan Ran To the Engine") // Or a Gate dropping to Closed position
   DONE
   
  ONTHROW (1) DELAY(1000) PRINT("Throw Turnout 1 to Track A, Signal Red")
   RED (106)              PRINT ("T1 Thrown ~ A RED")
   DONE
  ONTHROW (2) DELAY(1000) PRINT("Throw Turnout 2 to Track A, Signal Red")
   RED (108)              PRINT ("T2 Thrown ~ A RED")
   DONE
  ONTHROW (3) DELAY(1000) PRINT("Throw Turnout 3 to Track C, Signal Red")
   RED (110)              PRINT ("T3 Thrown ~ C RED")
   DONE
/*  ONTHROW (4) DELAY(1000) PRINT("Throw Turnout 4 to Track C, Signal Red") //Uncomment this Line If you want to use vpin 112 & 113 as a turnout
   RED (112)              PRINT ("T4 Thrown ~ C RED")                      //later we are going to use vpin112,113 as a FX Arc Welder instead
   DONE
*/
// ACCESSORY TEST SERVO vpin100 Verify a Printed response
  ONTHROW(0)     // Set Accessory Test Servo 0 thrown
   DELAY(2000)
   PRINT("Test Servo 0 Position Thrown")
   DONE
   
// ACCESSORY SERVO vpin105  Verify a Printed response
  ONTHROW(5)     // Set Accessory Servo 5 Thrown
   DELAY(2000)
  //PRINT("Accessory Servo 5 Thrown ")
 // or
   PRINT("Railfan Ran Away From the Engine") //Or a Gate Opened to the Up position
   DONE

///||||||||||||||||||| End of Lesson 102 Macro to Individually  CLOSE & THROW Turnouts |||||||||||||||||||||||||||||||||||


// *********************************************************************************************************************** //
// EXRAIL Course Lesson 103 using EXRAIL to COMBINE the ONCLOSE & ONTHROW in Lesson 102 Above       --- Tinkerer Level
// *********************************************************************************************************************** //
// Set the opposing Turnouts at the Same time, Only recommended IF you want to Force two Turnouts to Always be together
// I Leave the two turnouts Separate so that Student Train Drivers can set turnouts Individually and Learn as they grow.
// IF you uncomment and use these macros below you Must then Comment Out the Single ONCLOSE & ONTHROW Macros Above, 
// Duplicate ONCLOSE & ONTHROWS give compile Errors.
/*
// SEQUENCE(101) PRINT ("Close Both Turnouts 1 & 2 to Track B, Signals Green") 
   //Only use this if you want the two apposing turnouts to sync. Note we Build a Route below to do this instead.
  ONCLOSE (1)
   DELAY (1000)
   GREEN (106)   PRINT ("T1 Closed ~ B GREEN")
  CLOSE (2)      
   DELAY (500)
   GREEN (108)   PRINT ("T2 Closed ~ B GREEN")
   DONE
//SEQUENCE (102) PRINT ("Throw Both Turnouts T2 & T1 to Track A, Signals RED")
  ONTHROW (1) 
   DELAY (1000)
   RED(106)      PRINT ("T1 Thrown - A RED")
   THROW (2) 
   DELAY(1000) 
   RED (108)     PRINT ("T2 Thrown - A RED")
   PRINT("T2 & T1 Thrown ROUTE A Track A RED")
   DONE
*/

///||||||||||||||||||||| End of Lesson 103 Combine the ONCLOSE & ONTHROW Turnouts ||||||||||||||||||||||||||||||||||||||


// ********************************************************************************************************************* //
// EXRAIL_Courses Lesson 103 using EXRAIL to Create ROUTEs to manually control Turnouts             --- Tinkerer Level
// Create Simple ROUTEs to Track A and Track B between Stations. 

// This Route setup is similar to Combined Turnout T1 & T2 movement above and also produces a ROUTE "name" {Set} button 
//  in engine Driver to control as many turnouts in one Route as you like
// ********************************************************************************************************************* //
 ALIAS(Route_Track_A_B, 12438)
  ROUTE(Route_Track_A_B, "Route To Track A from B") PRINT("")PRINT("Set ROUTE To Track A from B")
   THROW (1)  //  Set Turnout 1 to Track A LED Red
   THROW (2)  //  Set Turnout 2 to Track A LED Red
  DONE
 ALIAS(Route_Track_B_A, 11286)
  ROUTE(Route_Track_B_A, "Route To Track B from A") PRINT("")PRINT("Set Route To Track B from A")
   CLOSE (1)  //  Set Turnout 1 to Track B LED Green
   CLOSE (2)  //  Set Turnout 2 to Track B LED Green
  DONE

//  You can uncomment these two if you want to use Servo Turnouts on Vpin103 & 104 
//    and Red vpin112 and Green vpin113 LEDs
//  BUT further down we'll be creating Special FX lighting effects macros and will be using these two vpins 112 & 113
/*
 ALIAS(Route_Track_C_B, 10264)
  ROUTE(Route_Track_C_B, "Route To Track C from B") PRINT("")PRINT("Set ROUTE To Track C from B")
   THROW (3)  //  Set Turnout 3 to Track C LED Red
   THROW (4)  //  Set Turnout 4 to Track C LED Red
  DONE
 ALIAS(Route_Track_B_C, 11288)
  ROUTE(Route_Track_B_C, "Route To Track B from C") PRINT("")PRINT("Set Route to Track B from C")
   CLOSE (3)  //  Set Turnout 3 to Track B LED Green
   CLOSE (4)  //  Set Turnout 3 to Track B LED Green
  DONE
*/

//|||||||||||||||||||||||||||||  End of Lesson 103 ROUTEs Track A & B   |||||||||||||||||||||||||||||||||||||||||||||||||

// ********************************************************************************************************************** //
// EXRAIL Course Lesson 103 Using Macros for Accessory Servo Animation & Special FX Effect Lighting    --- Tinkerer Level
// The Following are Multiple Macros to handle Accessory Servo Movement, Signal Lighting & Special Effects
//  to CALL(n)into your EXRAIL scripts, and/or you can control them from your Engine Driver & WiThrottle Cellphone Apps.
//
// ********************************************************************************************************************** //

// ********************************************************************************************************************** //
// Servo Accessory Automation Macros for very slow motion servo moving side to side or up & down       --- Tinkerer Level
// Create a slow motion Railfan Walking To Train <---> From Train on a Engine Driver {Set} buttons
// Change the vpin SERVO(105, below to the Servo you wish to use as the Accessory Walking servo or Gate Lift Servo
// Special Accessory Servo Animation Sequence(n), by using a ROUTE(n) we create a Engine Driver & WiThrottle button
// From Engine Driver the First press of a FX {Set} button will turn them ON, and a Second press turns them OFF.
// ********************************************************************************************************************** //

// One-shot-0nly button press script for Engine Driver Route{Set} button
// Callable for EXRAIL interface JMRI Menu GUI 'Railfan' button to Send </START 880> START880.py script by KCSmith 12-3-21
  ROUTE(880, "FX Railfan to <-> from Train/Annex") // a Engine Driver R880{Set} One button push
    IF(220)LATCH(220)CALL(100)// SEQUENCE(100) Walking To Train - Clockwise (Close)
    UNLATCH(220)DONE ENDIF   // Dummy pin(220)Limits SEQ(100) & SEQ(101) OR ROUTE(880))to ONE button push
    LATCH(220)CALL(101)     // SEQUENCE(101) Walking From Train - Counter Clockwise (Throw)
    DONE

 SEQUENCE(100) // CALL(100) this SEQ inside EXRAIL scripts Railfan or Baggage Handler Walking Out of the Annex to the Train
// New Servo2(vpin, inactiveAngle, duration) // Accessory Servo move to angle taking xx seconds to closed position
   SERVO2(105, 100, 10000) // vpin105 move to 100angle taking 10 seconds travel time to {Closed}
   PRINT ("Walked To the Train") // - Clockwise
 //DONE  // by commenting out DONE we use RETURN instead to continue from your EXRAIL script CALL(n)
  RETURN // Returns back to your CALL(100) after this Sequence(100) is completed
  
 SEQUENCE(101) // CALL this SEQ inside EX-Rail scripts as Railfan Or Baggage Handler Walking back Inside of the Annex
// New Servo2(vpin,activeAngle, duration) // Accessory Servo move to angle taking xx seconds to thrown position
  SERVO2(105, 490, 10000) // vpin105 move to 490angle taking 10 seconds travel time {Thrown}
   PRINT ("Walked Away from the Train") // - Counter Clockwise
 //DONE  // by commenting out DONE we use RETURN instead to continue from your EXRAIL script CALL(n)
  RETURN // Returns back to your CALL(101) after this Sequence(101) is completed


//|||||||||||||||||||||||||||||| End of Lesson 103 Accessory Servo Railfan ||||||||||||||||||||||||||||||||||||||||||||||||

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// EXRAIL Course Bonus FX Effects using EXRAIL to Create Special Lighting & Sound Effects              --- Tinkerer Level
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// EXRAIL Course Lesson 103 using EXRAIL to Create Special Lighting Effects FX using FADE for LEDs     --- Tinkerer Level
// FADE( pin, value, ms ).  Fade an LED on a PCA9685 servo driver to given value and taking a given time
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// ********************************************************************************************************************* //
// KC Smith's Bonus FX-Effects with Special Caution & Crossing Signal Lighting Effects                --- Tinkerer Level
// Sequence(22) & (23) Trip Sensors {Sns22} & {Sns23} to activate & deactivate Flashing Caution & Crossing Signals
// Use CALL(n) to use them into your scripts, or use Send </START 881> from a IDE Serial Monitor or JMRI Traffic Monitor
// Special Effects Sequence using a ROUTE(n) to create a Engine Driver & WiThrottle {Set} button to control Effects
// From Engine Driver the First press of a FX {Set} button will turn them ON, and a Second press turns them OFF.
// ********************************************************************************************************************* // 

// ********************************************************************************************************************* //
//  One-Button Press from Engine Driver{Set} & WiThrottle {Route} to turn On, press again to turn Off --- Tinkerer Level
// ********************************************************************************************************************* //
// A single 1st press of Engine Driver R881 'FX Caution Signals On/Off' {Set} button turn it ON
// A second 2nd press of Engine Driver {Set} button allows it to cycle one more time then Stop and turns it OFF
   ROUTE(881, "FX Caution Signals On/Off") // a Engine Driver R881{Set} One button push
    IF(221) UNLATCH(221) LATCH(22) DELAY(1500) UNLATCH(22) PRINT("FX Caution Signals OFF") DONE ENDIF
       // Dummy pin(221) Limits SEQUENCE(22) turns Vpin 114 & 115 On & Off
    PRINT("FX Caution Signals ON")
    LATCH(221) CALL(22)  // SEQUENCE(22) X-ON Caution Signals
   DONE

    // Note; Sensor 22 {Sns22} trip also turns Off the Caution Signals
    
// ********************************************************************************************************************** //
// Special Sensor trips Lighting Effect for Caution & Crossing Signals, Similar to the Macro 100 above --- Tinkerer Level
//  Alternating LEDs Either Caution Signals {Yellow, Yellow} Or Crossing Signals {Red, Red} on Pins 114-115 PCA9685 board 
// Use these macros in your scripts with CALL(n) and it will run the macro then return to your original script 
//  FADE( pin, intensity_value, ms ) Fade an LED on a servo board with a given intensity and taking a given time
// ********************************************************************************************************************** //

// "X-Caution Signals ON" For Sensor Sns22 on D22
 SEQUENCE(22)   // Train is in Station A on top of Sensor Sns22 Caution Signal Lights
  IFNOT(22)        // Signal Lights as long as Sensor {Sns22} uncovered
  FADE(115, 0, 0)
  FADE(114, 1000, 0)
  DELAY(750)
  FADE(114, 0, 0)
  FADE(115, 1000, 0)
  DELAY(750)
  FOLLOW(22)       // Repeat until {Sns22} is Low
  ENDIF            // IF {Sns22} Then END Sequence (22)
  FADE(114, 0, 0)  // Turn off Signals 
  FADE(115, 0, 0)   
 RETURN            // Go back to your script and continue on from your EXRAIL CALL(22)

// "X-Caution Signals ON"  For Sensor Sns23 on D323
 SEQUENCE(23)      //Train is in STATION B on top of Sensor {Sns23}
  IFNOT(23)        // Sensor {Sns23} Signal Lights On as long as Sns23 is uncovered
  FADE(115, 0, 0)
  FADE(114, 1000, 0)
  DELAY(750)
  FADE(114, 0, 0)
  FADE(115, 1000, 0)
  DELAY(750)
  FOLLOW(23)       // Repeat until {Sns23} is Low
  ENDIF            // IF {Sns23} Then END Sequence(23)
  FADE(114, 0, 0)  // Turn off Signals 
  FADE(115, 0, 0)   
 RETURN            // Go back to the script and continue on from your EXRAIL CALL (23)

//|||||||||||||||||||||||||||||||| End of Lesson 103 Caution Signals ||||||||||||||||||||||||||||||||||||||||||||||||||||||


// *********************************************************************************************************************** //
//  KC Smith's Bonus Sample FX Special Lighting Effects for LEDs with FADE Function                   --- Tinkerer Level         
//  Sequence(112) Arc Welder and Sequence(114) Campfire or Bonfire
//  You can use Send </START 112> or </START 114> from a Serial Monitor or Traffic Monitor to Start & Stop them,
//  And use Engine Driver{Set} & WiThrottle{Route} buttons to start and stop them.
//       
// Special Lighting Effect Sequence, by using a ROUTE(n) we create a Engine Driver{Set} & WiThrottle{Route}buttons
// *********************************************************************************************************************** //

// *********************************************************************************************************************** //
// "FX Arc Welder" with a Dual LEDs. One clear White LED on vpin112 and One Blue LED on vpin113        --- Tinkerer Level
//  IF you're using vpins 112 & 113 for a turnout or a point signal then use another vpin# on another a PCA9685 board
// A single 1st press of Engine Driver R882 'FX Arc Welder On/Off' {Set} button turns it ON.
// A second 2nd press of Engine Driver {Set} button allows it to cycle one more time then Stop and turns it OFF.
// *********************************************************************************************************************** //
 ROUTE(882, "FX Arc Welder On/Off") // Create a dummy One button press macro
   IF(222) UNLATCH(222)  // Dummy pin(222) Limits SEQUENCE(112)
           DONE ENDIF  
    PRINT("FX Arc Welder ON")
   LATCH(222) START(112) // SEQUENCE(112) Dual FX Arc Welder turns Vpins 112 & 113 rapidly On & Off
   DONE
   
 SEQUENCE(112)           // Dual LED FX Arc Welder {R1 200ohm on a PCA9685 Signal Board vpin 112 & 113}
  SET(1503)              // Optional DFPlayer Arc Welder Sound file vpin 1503
// FADE(vpin, intensity, duration) intensity is from 0 to 4095 brightest.
   FADE(112, 4000, 50)   // Clear White LED
   FADE(113, 4000, 40)   // Clear Blue LED 
   FADE(113,  400, 40)
    DELAYRANDOM(50,600)
   FADE(113,    0, 20)
   FADE(112,    0, 20)   
    DELAYRANDOM(50,800)
   FADE(112, 4000, 40)  
   FADE(113, 4000, 60)  
   FADE(113,  250, 40)  
    DELAYRANDOM(50,100) 
   FADE(113,    0, 40)
   FADE(112,    0, 40)  
    DELAYRANDOM(50,600)
   FADE(112, 4000, 40)
   FADE(113, 4000, 40)
   FADE(113, 1000, 20)
    DELAYRANDOM(50,200)
   FADE(113,    0, 20)
   FADE(112,    0, 20)
    DELAYRANDOM(50,500)
   FADE(112, 4000, 60)
   FADE(113, 4000, 40)
   FADE(112,  500, 20) 
   FADE(113, 1000, 40) 
    DELAYRANDOM(50,300) 
   FADE(113,    0, 50)
   FADE(112,    0, 50)   
    DELAYRANDOM(200,1000)
   FADE(112, 4000, 40)
   FADE(113, 4000, 60)
   FADE(112,  600, 60)
   FADE(113, 1000, 40)
    DELAYRANDOM(100,200)
   FADE(113,  600, 40)
   FADE(113,    0, 20)
   FADE(112,    0, 20)
    DELAYRANDOM(50,200)
   FADE(113, 4000, 40) 
   FADE(112,  500, 40)
   FADE(112,    0, 20)
    DELAYRANDOM(50,200)
    
  IF(222) FOLLOW(112) ENDIF
   RESET(1500)      // Turn Off Optional DFPlayer Sound file
   FADE(112, 0, 0) PRINT("FX2 Arc Welder OFF") // Turn Dual Welder Off
   FADE(113, 0, 0)  // Turn Dual LED Welder Off
   ENDTASK

// ********************************************************************************************************************* //
// "FX Campfire" use a Red or Amber LED on vpin114 and Gnd
// IF you're using vpinb 114 for a turnout or a point signal Or FX Signal then use another vpin# on another PCA9685 board 
//  KC Smith's Special Lighting Effect Sequence, by using a ROUTE(n) we create a Engine Driver & WiThrottle button
// A single 1st press of a Engine Driver R883 'FX Campfire On/Off' {Set} button turns it ON
// A second 2nd press of a Engine Driver {Set} button allows it to cycle one more time then Stop and turns OFF
// ********************************************************************************************************************* //
  ROUTE(883, "FX Campfire On/Off")  // Create a dummy One button press macro
    IF(223) UNLATCH(223) DONE ENDIF // Dummy pin(223) Limits SEQUENCE(114)
    PRINT("FX Campfire ON")
    LATCH(223) START(114) // SEQUENCE(114)FX-ON Campfire turns Vpin On & Off
    DONE
  SEQUENCE(114) // Working Campfire or Bonfire {R1 220ohm on a PCA9685 Signal Board Vpin 114}
   SET(1506)    // Optional DFPlayer Campfire Sound vpin1506
  // for a campfire effect we lower the intensity or lengthen the delay for the lower intensity lines
  //FADE(vpin, intensity, duration) intensity is from 0 to 4095 brightest.
   FADE(114, 150, 50)   DELAYRANDOM(200,800) // Use a Amber or Red LED
   FADE(114, 500, 30)   DELAYRANDOM(200,1000)
   FADE(114,  75, 75)   DELAYRANDOM(200,400)
   FADE(114, 750, 30)   DELAYRANDOM( 50,500)
   FADE(114,  75,100)   DELAYRANDOM(100,1500)
   FADE(114, 250,100)   DELAYRANDOM(100,600)
   FADE(114, 2500, 5)   DELAYRANDOM( 50,250)
   FADE(114,  75, 75)   DELAYRANDOM(200,1000)
   FADE(114, 400, 30)   DELAYRANDOM( 50,600)
   FADE(114,  75,100)   DELAYRANDOM(200,1500)
   FADE(114, 1500,10)   DELAYRANDOM( 50,250)
   
   IF (223) FOLLOW(114) ENDIF 
   RESET(1500)   // Turn Off Optional DFPlayer sound file
   FADE(114, 0, 0) PRINT("FX Campfire OFF") // Turn Campfire Off
   ENDTASK

// ************************ End of Bonus Special FX Effects Lesson 103  ******************************************* //
// **************************************************************************************************************** //


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// EXRAIL Course Lesson 104  Momentary Mimic Panel buttons for Turnouts & Servo Accessories       --- Tinkerer Level
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// ****************************************************************************************************************** //
// Setup Mega Mimic Panel buttons to control Turnouts and Servo Accessories                       --- Tinkerer Level
// These six momentary mimic panel push button macros work on Mega Dpin 30-35 to ground.
// Press Momentary Panel Button or a Engine Driver Throttle Turnout Close/Throw button  
// ****************************************************************************************************************** //
// Add Panel momentary push buttons for Turnouts

 AUTOSTART SEQUENCE(30) 
  AFTER(30) DELAY(250)                        // When button on Dpin 30 is pressed
   CLOSE(0) //PRINT("Panel button T0 Close")  // Turnout {Close}
   DELAY(250)
  AFTER(30) DELAY(250) 
   THROW(0) //PRINT("Panel button T0 Throw")  // Turnout {Throw}
   DELAY(250)
  FOLLOW(30)
   
 AUTOSTART SEQUENCE(31)
  AFTER(31) DELAY(250)                        // When button on Dpin 31 is pressed
   CLOSE(1) //PRINT("Panel button T1 Close")  // Turnout {Close}
   DELAY(250)
  AFTER(31) DELAY(250) 
   THROW(1) //PRINT("Panel button T1 Throw")  // Turnout {Throw}
   DELAY(250)
  FOLLOW(31)
   
 AUTOSTART SEQUENCE(32)
  AFTER(32) DELAY(250)                        // When button on Dpin 32 is pressed
   CLOSE(2) //PRINT("Panel button T2 Close")  // Turnout {Close}
   DELAY(250)
  AFTER(32) DELAY(250) 
   THROW(2) //PRINT("Panel button T2 Throw")  // Turnout {Throw}
   DELAY(250)
  FOLLOW(32)
   
 AUTOSTART SEQUENCE(33)
  AFTER(33) DELAY(250)                        // When button on Dpin 33 is pressed
   CLOSE(3) //PRINT("Panel button T3 Close")  // Turnout {Close}
   DELAY(250)
  AFTER(33) DELAY(250) 
   THROW(3) //PRINT("Panel button T3 Throw")  // Turnout {Throw}
   DELAY(250)
  FOLLOW(33)
   
 AUTOSTART SEQUENCE(34)
  AFTER(34) DELAY(250)                        // When button on Dpin 34 is pressed
   CLOSE(4) //PRINT("Panel button T4 Close")  // Turnout {Close}
   DELAY(250)
  AFTER(34) DELAY(250) 
   THROW(4) //PRINT("Panel button T4 Throw")  // Turnout {Throw}
   DELAY(250)
  FOLLOW(34)

// ********************************************************************************************************* //
// * ALTERNATE Slow Motion Momentary Mimic Button Macro 
// ********************************************************************************************************* //
// Momentary Mimic Panel push button for Slow Motion "Walking Railfan Train <-> Annex"
// This Momentary mimic panel push button macro works on Dpin35 to ground.
// SERVO2(id, position, duration) Move an Animation servo taking duration in mS. 
//  Do NOT Use for Turnouts
// (id105 , Vpin105, 490angle, 10seconds)  

 AUTOSTART SEQUENCE(35)
  AFTER(35) DELAY(250)                                            // When button on Dpin 35 is pressed
   SERVO2(105,490,10000) //PRINT("Railfan Walking Back To Annex") // Walk Counter-Clockwise {Thrown}
   DELAY(250)
  AFTER(35) DELAY(250) 
   SERVO2(105,110,10000) //PRINT("Railfan Walking To Train")      // Walk Clockwise {Close}
   DELAY(250)
  FOLLOW(35)

// *****************  End of Lesson 104 Momentary Mimic Panel Push Buttons on D30- D35  *************************** //
// **************************************************************************************************************** //


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// EXRAIL Course Lesson 104 CLEVER Macro to combine the macros in Lesson 103 Above         -- Clever Tinkerer Level
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ********************************************************************************************************** //
// Now that we have Servo Turnouts, Signals & Panel Buttons defined here is a
// New Clever way to combine All three Turnouts, Buttons & Signals together into One macro.
// Use a #define command to create a new user EXRAIL Function then ("describe it") and use it in a macro.
// ********************************************************************************************************** //
/*
#define CLEVER(turnout,button,signal) \
   AUTOSTART SEQUENCE(turnout) \
   AFTER(button) THROW(turnout) BROADCAST("<* " #turnout " Thrown *>") DELAY(1000) \
   AFTER(button) CLOSE(turnout) BROADCAST("<* " #turnout " Closed *>") DELAY(1000) FOLLOW(turnout) \
    ONTHROW(turnout) RED  (signal) DONE \
    ONCLOSE(turnout) GREEN(signal) DONE
   CLEVER (100, 30,   0)  //  Servo  0, Button 30, { no LED signals}  Servo Used as an Accessory SERVO(0)
   CLEVER (101, 31, 106)  // Turnout 1, Button 31` {106 Red & Green}
   CLEVER (102, 32, 108)  // Turnout 2, Button 32, {108 Red & Green}
   CLEVER (103, 33, 110)  // Turnout 3, Button 33` {110 Red & Green}
   CLEVER (104, 34, 112)  // Turnout 4, Button 34, {112 Red & Green}
   CLEVER (105, 35,   0)  //  Servo  5, Button 35, { no LED signals}  Servo Used as an Accessory SERVO(5)
*/

// ***************** End of Lesson 104 Clever Macro Turnots, Buttons & Signals ************************************ //
// **************************************************************************************************************** //


// ************  Commands via Engine Driver{Set} & WiThrottle{Route} buttons ***************
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// EXRAIL Course Lesson 105 Creating System Commands to run on WiFi Throttle Apps              ---  Tinkerer Level
// Use EXRAIL ROUTE(n) for Engine Driver & WiThrottles App Command buttons
// The macros sort by Description so we use "Cmd # description" to put them in the order we want them in
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Special EXRAIL Engine Drive Function keys, Used to Send DCC++EX Commands to PowerOn PowerOff the Command Station
 ROUTE(Cmd_POWERON,  "Cmd 1 Power All ON ")PRINT("Power ON MAIN & PROG")
  POWERON
  JOIN
  DONE
  ROUTE(Cmd_POWEROFF, "Cmd 1 Power All OFF")PRINT("Power OFF MAIN & PROG")
  POWEROFF
  DONE 

// Special EXRAIL Engine Driver Function keys, Used to Send DCC++EX Commands to change PROG Track Functions
 ROUTE(Cmd_JOIN, "Cmd 2 JOIN=PROG")  // Sends the DCC Main Waveform to the PROG Track for Testing and Drive Away
  JOIN
  PRINT("PROG Joined to MAIN, Ready to Test or to 'Drive Away'")
  DONE
 ROUTE(Cmd_UNJOIN,"Cmd 2 UNJOIN PROG~") // Place PROG back in Programming mode
  UNJOIN
  PRINT("PROG - Unjoined and Available for Programming")
  DONE

// Special EXRAIL Engine Drive Function keys, Used to Send DCC++EX Commands to Pause & Resume Animations
 ROUTE(Cmd_PAUSE, "Cmd 3 Pause")PRINT("Pause EX-RAIL Tasks")   // PAUSE all EXRAIL Animations
  PAUSE
  DONE
 ROUTE(Cmd_RESUME,"Cmd 3 Resume")PRINT("Resume EX-RAIL Tasks") // RESUME all EXRAIL Animations
  RESUME
  DONE

// Special EXRAIL Speed Step Settings Speedstep 28 and Speedstep 128
 ROUTE(Cmd_SpeedStep_28,"Cmd 4 SpeedStep 28")PRINT("Speedstep 28 SET")
  PARSE("<D SPEED 28>")
  DONE
 ROUTE(Cmd_SpeedStep_128,"Cmd 4 SpeedStep 128")PRINT("Speedstep 128 SET")
  PARSE("<D SPEED 128>")
  DONE

// Special PARSE Command Allows you to Run DCC-EX Commands from the WiFi Throttles
// Caution; Special Administrator Commands to Reboot the CS and KILL EX-Rail Threads
 ROUTE(911,"Cmd 5 Reboot CS")PRINT("ESTOP! & Rebooting Command Station in 1 second")
  DELAY(1000)
  PARSE("<!>")
  DELAY(500)
  PARSE("<D RESET>")
  DONE
   
// Special, Use KILL EXRAIL Tasks command Sparingly to abort a running Automation or Thread. 
 ROUTE(912,"Cmd 6 CS KILL ALL EXRAIL Tasks") 
   PRINT("List of Current Tasks Running")
  PARSE("</>") // List tasks
   DELAY(1000)
   PRINT("KILLing Only All EXRAIL Tasks Running on the CS")
   PRINT("**** Caution this will Emergency Stop! ONLY Locos in EXRAIL AUTOMATION's ")
   PRINT("but leave Manual Locos Running & the Turnouts & Servos & FX effects Stopped as is ****")
  ESTOP
  KILLALL
   DELAY(2000)
   PRINT("")
  DONE 

// Cleans up any FX Lighting that stays on after a Task is aborted. Edit or add to the vpin list as needed.
 ROUTE(913,"FX Clear FX Devices & Lighting") PRINT("") PRINT("Clear Special Effects FX Devices & Lighting")
// KC Smith {ShutOff} Caution & Crossing Signals, Arc Welder & Campfire LEDs etc.,
  SIGNAL(112, 0, 113)    // Signal Point 4 OR Special Effect LED
   RESET(112) DELAY(100) // Arc Welder White LED
   RESET(113) DELAY(100) // Arc Welder Blue  LED for HCSR04 Ultrasonic sensor
  SIGNAL(114, 0, 0)      // Caution Or Campfire Signal 114
   RESET(114) DELAY(100) // Blinking FX Caution & Crossing
  SIGNAL(115, 0, 0)
   RESET(115) DELAY(100) // Blinking FX Caution & Crossing
  RESET(1500) DELAY(100) // DFPlayer Optionally using the Virtual vpin 1500
  RESET(2000) DELAY(100) // HC-SR04 Sonic Sensor Optionally using the Virtual vpin2000 with a Blue LED on vpin 113
   PRINT("FX Devices and Lighting Cleared")
   PRINT("")
  DONE
/*
 ROUTE(914,"Cmd 7 User Defined Command")PRINT("Open User Defined command")
  PARSE("<   >")
  DELAY(500)
   DONE
 */               
 
   // Uncomment the /*   */ characters to use these commands
/*
// Command via Engine Driver & WiThrottle buttons
// Special Developers Diagnostics commands that display in the IDE Serial Monitor & JMRI DCC++ Traffic Monitors
// Uncomment the commands you wish to use from a WiFi Throttle
 ROUTE(920,"Cmd 8 Diagnostics ? ON")PRINT("Diag ACK, CABS, CMD, EXRAIL, HAL, RAM, WIFI & WIT, TM= on Command Station Monitor")
  DELAY(500)
//PARSE("<D ACK ON>")   // Enables ACK diagnostics
//PARSE("<D CABS ON>")  // Shows cab numbers and speed in reminder table
//PARSE("<D CMD ON>")   // Enables Command Parser diagnostics
  PARSE("<D EXRAIL ON>")// Turns on/off diagnostic traces for EX-RAIL events
  PARSE("<D HAL SHOW>") // Shows configured servo board and GPIO extender board config and used pins
  PARSE("<D RAM>")      // Free Ram Status
//PARSE("<D WIFI ON>")  // Enables WiFi diagnostics
//PARSE("<D WIT ON>")   // Enables WiThrottle diagnostics
//PARSE("<=>")          // TrackManagerTM Mode Status v4.2.4+
//PARSE("<c>")          // CS Current status check for JMRI
//PARSE("<D     >")     // User define cmd
   DONE

 ROUTE(921,"Cmd 8 Diag OFF")PRINT("Diag OFF - ACK,CABS, CMD, EXRAIL, WIFI & WIT Command Station")
  DELAY(500)
  PARSE("<D ACK OFF>")
  PARSE("<D CABS OFF>")
  PARSE("<D CMD OFF>")
  PARSE("<D EXRAIL OFF>")
  PARSE("<D WIFI OFF>")
  PARSE("<D WIT OFF>")
//PARSE("<D     OFF>")   // user defined
   DONE
*/

// *** Bonus DFPlayer Volume and Play P/N buttons for Engine Driver & WiThrottles *** 
 ROUTE(1510,"FX DFPlayer Volume 10")PRINT("Set DFPlayer Volume to 10")
  PARSE("<D ANOUT 1501 10 Instant>")
  DELAY(250)
   DONE
 ROUTE(1520,"FX DFPlayer Volume 20")PRINT("Set DFPlayer Volume to 20")
  PARSE("<D ANOUT 1501 20 Instant>")
  DELAY(250)
   DONE
 ROUTE(1530,"FX DFPlayer Volume 30")PRINT("Set DFPlayer Volume to 30")
  PARSE("<D ANOUT 1501 30 Instant>")
  DELAY(250)
   DONE

//  *** TESTING Work In Progress Do Not Use ****
// Bonus FX DFPlayer Next Previous Sound commands
/*
 ROUTE(1545,"FX DFPlayer Previous")PRINT("DFPlayer Previous")
  SET(45)      // Dpin 45 to DFPlayer IO1 J1 Previous
   DELAY(250)
  RESET(45)  
  DONE
 ROUTE(1546,"FX DFPlayer Next")PRINT("DFPlayer Next")
  SET(46)      // Dpin 46 to DFPlayer IO2 J3 Next
   DELAY(250)
  RESET(46)  
  DONE 
*/

// *** TESTING Work In Progress on different Engine Driver & Withrottle buttons for DFPlayer features ****
// Bonus FX DFPlayer # Sound commands that play Individuale Audio sounds directly
// Uncomment the commands you wish to use from a WiFi Throttle
 ROUTE(1550,"FX DFPlayer # Sound")// a Engine Driver{Set} & WiThrottle{Route} button
  PRINT("Play DFPlayer file# ON")   // OR Start & Stop it with </START 1550> command Or a Direct pin with <Z 1500n 1>
// PARSE("<Z 1500 1>")  // Play  1st sound  Please Step Back
// PARSE("<Z 1501 1>")  // Play  2nd sound  We Thank You
// PARSE("<Z 1502 1>")  // Play  3rd sound  X-Bell
// PARSE("<Z 1503 1>")  // Play  4th sound  Arc Welder 
// PARSE("<Z 1504 1>")  // Play  5th sound  Can you Fill The Tank?
// PARSE("<Z 1505 1>")  // Play  6th sound  Water Filling Tank
// PARSE("<Z 1506 1>")  // Play  7th sound  Campfire
   PARSE("<Z 1507 1>")  // Play  8th sound  All Aboard
// PARSE("<Z 1508 1>")  // Play  9th sound  Arriving Track A
// PARSE("<Z 1509 1>")  // Play 10th sound  Arriving Track B
// PARSE("<Z 1510 1>")  // Play 11th sound  Big Ben Chime
// PARSE("<Z 1511 1>")  // Play 12th sound  Polar Express You Coming?
// PARSE("<Z 1512 1>")  // Play 13th sound  Polar Express Train Arrive on his Block
// PARSE("<Z 1513 1>")  // Play 14th sound  Polar Express Santa Sleigh Ride 
// PARSE("<Z 1514 1>")  // Play 15th sound  Open for User Defined
   WAITFOR(1507)        // Change this # to Match the number of your uncommented 1500#
  PRINT("Play DFPlayer file# OFF") 
  ENDTASK

// ************* End of Lessson 105 Creating System Commands to run on WiFi Throttles *********************** //
// ********************************************************************************************************** //

//|||||||||||||||||| End of EXRAIL Courses LESSONS 101 - 105 Special Macros |||||||||||||||||||||||||||||||||
//|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||


// ***************** Bonus EXRAIL Special Effects FX Devices Accessory Macros ****************************** //
// ********************************************************************************************************* //
 // EXRAIL Courses_100_Macros  Bonus Device Accessory Macros                       -- Tinkerer Higher Level
 //       + Lesson 106  Sample DFPlayer MP3 Micro-SD card for sounds                              + Works +
 //       + Lesson 107  Sample HC-SR04 Ultrasonic Sensor with Blue LED & DFPlayer mini MP3 sounds + Works +
 //       ~ Lesson 108  Sample Crossing Signal Lights, Servo Gate & DFPlayer mini MP3 sounds      ~Testing~ 
// ********************************************************************************************************* //


// *********************************************************************************************************** //
// Lesson 106 Sample DFPlayer mini MP3 Sound card                                         --- Tinkerer Level
//  Optional DFPlayer mini MP3 Micro-SD Sound Card Player                                          + Works +
//   Using DFPlayer setup in myHal.cpp on vpin1500, Serial 1, with up to 15 sounds on vpins 1500-1514 
//  To trip use Any sensor on the Mega Dpins Or any Virtual vpin Sensor
//   Using Mega dpin(25) Sensor Sns25, OR change this and move it to another Mega dpin or GPIO Vpin.
// A single button press from Engine Driver R884 'FX DFPlayer MP3 On/Off' {Set} button turns it to READY
//  Continually monitors Sns{25} Dpin(25), when tripped it plays.
// A second 2nd press from Engine Driver {Set} button allows it to cycle one more time then Stop and turns OFF
// *********************************************************************************************************** //

  ROUTE(1525, "FX DFPlayer Sns25 On/Off ") // an Engine Driver & WiThrottle R1525{Set}button 
                                          // OR Start & Stop it with </START 1525> command
    IF(225)                  // Dummy pin(225) Limits ROUTE(1525)to One button push
     UNLATCH(225)DONE ENDIF  // pin(225)Unlatched Second Push button Turn off Player
    LATCH(225) START(1000)   // Latch then start SEQUENCE(1000)Play Sound
    DONE
     
  SEQUENCE(1000)PRINT("FX DFPlayer Sensor Sns25 Ready")
    AT(25)                            // At Sensor{Sns25} Tripped Play 1st Sound file
     PRINT("DFPlayer Sound ON")
    SET(1509)                         // Use Any DFPlayer Virtual# vpin1500x to trip & Play Sound files  {Works}
 //  SERVO(1500,9,Instant)            // DFPlayer play 10th sound file              {Works bug} only plays twice
     PRINT("FX DFPlayer 10th Sound")  // Plays 10th Sound Arrival on Track B played
    WAITFOR(1509)                     // wait for vpin(n) file being played to complete

    AT(-25)                           // Sensor(Sns25} Released,
    SET(1501)                         // DFPlayer vpin1501 2nd sound file           {Works}
 //  SERVO(1500,2,Instant)            // DFPlayer play 2nd sound file               {Works bug} only plays twice
      PRINT("FX DFPlayer 2nd Sound")  
     WAITFOR(1501)                    // wait for vpin(n) file being played to complete
    RESET(1500)                       // DFPlayer Sound card Trips OFF
      PRINT("DFPlayer Sound OFF")

 //  SERVO(1501, 20, Instant)         // DFPlayer set Volume to 20                  {Works bug} works only once then stops playing
 //   PRINT("Sound Level Adjusted")
     
   IF(225) FOLLOW(1000) ENDIF         // A Second 2nd push of Engine Driver button Trips DFPlayer MP3 OFF   
    PRINT("FX DFPlayer Sensor Sns25 OFF ") 
    PRINT("Press the FX DFPlayer Sns25 {Set} button to turn it On")
   ENDTASK
    
//  **** IN LESSON PLANNING PHASE TO DO *****
// NOTE; To Set the DFPlayer Volume 0-30 from the IDE Serial command line use <D ANOUT 1501 20 Instant> // Set volume to 20

// ************************** End of Bonus Lesson 106 DFPlayer mini MP3 Sound Card *************************************** //
// *********************************************************************************************************************** //

// *********************************************************************************************************************** //
// Lesson 107 Sample HC-SR04 Ultrasonic Sensor with Blue LED & DFPlayer MP3 Sound Player combination   --- Tinkerer Level
// *********************************************************************************************************************** //
// The Ultrasonic Range Sensor detects people Too Close to the layout {30"-33" 80-85cm}                         + Works +
//  Using HC-SR04 Sonic Sensor setup in myHal.cpp as sensor on vpin2000 {Sns2000}, TRIG = D40, ECHO = D41
//
// The DFPlayer Plays Two sounds, "Please Step Back" and when they do it plays "We Thank You!"                  + Works +
//  Using DFPlayer setup in myHal.cpp on vpin1500, Serial 1, with 15 sounds on vpins 1500-1514
// A single 1st button press from Engine Driver R885 'FX UltraSonic Sensor On/Off'{Set} button turns it to READY
//  Continually monitors Ultrasonis Sensor Vpin Sns{2000}, Dpin 41 and when tripped it plays.
// A second 2nd press from Engine Driver {Set} button allows it to cycle one more time then Stop and turns OFF
// *********************************************************************************************************************** //
// "FX Ultrasonic Sensor" 
// Modified to trip a Blue LED FADE and Turn on a DFPlayer MP3 mini SD-card when you get within 33" or 85cm of the Sensor.
//  The HC-SR04 Ultrasonic Sensor is wired from a Mega 5v to VCC, D40 to TRIG, and D41 to ECHO, Gnd to Gnd. 
// Use the same BLUE LED on PCA9685 vpin113 and Gnd, IF you're using vpin113 for a turnout or a point signal
//  Or FX lighting, then use another vpin# for a FADE LED on another PCA9685 board
// DFPlayer MP3 Sound board Plays two messages when the Sensor is Tripped On & Off and the Blue LED Glows & Fades.
//  my HAL.cpp file Vpin1500 wired from Mega Serial 1, Tx1 Rx1 {18,19} to DFPlayer Rx & Tx pins.
//  {use a 1k ohm on the DFPlayer MP3 Rx pin to reduce noise on the line}

// KC Smith's Special FX Ultra Sound, Lighting Effect & MP3 Player Sequence and  
//  by using a ROUTE(n) we create a Engine Driver {Set} & WiThrottle {Route} buttons
// A single press for Engine Driver R885 'FX UltraSonic Sensor On/Off' {Set} button    

 ROUTE(885, "FX UltraSonic Sensor On/Off") // Create Engine Driver On/Off {Set} button press
                                                   // OR Start & Stop it with </START 885> command
   IF(225) UNLATCH(225)DONE ENDIF     // Dummy pin(225) Limits SEQUENCE(2020)
   LATCH(225) START(2020)DONE         // SEQUENCE(2020) FX Ultrasonic Sensor turns Vpin 113 Bright On to Fade Off

//  FX Ultrasonic Sensor can use AUTOSTART Infront of Sequence and startup at Command Station bootup
  SEQUENCE(2020)PRINT("FX UltraSonic Sensor Ready")
    AT(2000)                          // Sensor{Sns2000} Tripped They're Too Close to the Modular Layout.
     PRINT("FX UltraSonic Sensor ON") // Ultrasonic Sensor set to 80cm or 32" from back of Fascia
     FADE(113, 4095, 1600)            // BLUE LED Fader vpin 113 Bright Intensity, 1.6 Seconds
     PRINT ("PLEASE Step Back From The Module!!! ") // Message Played
     SET(1500)                        // DFFPlayer Plays 1st sound file
      WAITFOR(1500)                   // Wait For 1st sound to finish
      DELAY(1000)                     // delay 1 seconds
     SET(1500)                        // DFFPlayer Plays 1st sound file AGAIN
      WAITFOR(1500)                   // Wait For 1st sound to finish
     
    AT(-2000)                         // Sensor(Sns2000} Released, They Stepped Back Away from the Module. 
     FADE(113, 400, 400)              // BLUE LED Fader vpin 113 Dimm Intensity,
     PRINT("We Thank You! and Enjoy the Rest of Your Day") // Message Played
     SET(1501)                        // DFPlayer Plays 2nd sound file 
      WAITFOR(1501)                   // Wait For 2nd sound to finish
     RESET(1500)                      // DFPlayer MP3 Sound board Trips OFF
      PRINT("DFPlayer MP3 Sound OFF")
      FADE(113, 0, 200)               // BLUE LED Fader vpin113 Fade to Dim Intensity, .5 Second

   IF(225) FOLLOW(2020) ENDIF         // loop until unlatched {Second button press} Then Stop the Ultra Sonic Sensor
    PRINT("FX UltraSonic Sensor Not Ready") // print on the IDE Serial & JMRI DCC++ Traffic Monitors
    PRINT("Please Press the FX UltraSonic Sensor {Set} button to Restart")
    FADE(113, 0, 0)                   // Turns Blue LED OFF
   ENDTASK

// ************ End of Bonus Lesson 107 UltraSonic Sensor, Blue LED & DFPlayer Combined ****************************** // 
// ******************************************************************************************************************* //


//  **** IN LESSON PLANNING PHASE TO DO *****
// ******************************************************************************************************************* //
// BONUS Lesson 108 Level Crossing Gate & Signal with DFPLayer mini MP3 Sound Card         ---  Tinkerer Higher Level   
// ******************************************************************************************************************* //
//                      ************** ~Under Construction & Testing~ ************************* ~ Retest this Script ~
//                      *************** Not For General Distrabution ***************************
//                           
// Combining a slow moving Servo_Turnout wiyh Flashing Caution Signals (on the first PCA9685)
//  and DFPlayer Bell ringing sound for a Level Crossing Gate macroTrn 114 & 115 and Accessory Servo on vpin 100 T0 Zero
// Sensors Sns{24} & Sns{25 Trip them On, and Sns{22} & Sns{23} Turn them Off.
// New Servo2(vpin, inactiveAngle, duration) // Accessory Servo move to angle taking xx seconds to closed position
//
//A single button press from Engine Driver R887, "FX Level Gate Crossing & Signal On/Off'{Set} button turns it to READY
// A second 2nd press from Engine Driver {Set} button allows it to cycle one more time then Stop and turns OFF
// ******************************************************************************************************************** //
// One-shot-0nly button press script for Engine Driver Route{Set} button
// Callable for EXRAIL interface JMRI Menu GUI 'Railfan' button to Send </START 887> START887.py script by KCSmith 9-5-22
/*
 ROUTE(887, "FX Level Gate Crossing & Signal On/Off") // a Engine Driver R887{Set} One button push
  IF(887)                   // SEQUENCE(887) Gate Closing - Clockwise (Close)
    UNLATCH(887)DONE ENDIF  // Dummy pin(887) Limits ROUTE(887)to ONE button push
    PRINT("FX Crossing Gate & Signals Ready")
  LATCH(887) 
   START(2030) 
   START(2031)
   DONE
 
// AUTOSTART ROUTE(887, "FX Level Gate Crossing & Signal On/Off") //INSTEAD Skip ED push button & Auto Start Crossing Gate Signal script
   
// "X-Caution or Crossing Signals ON" 
  SEQUENCE(2030)   // Train is in STATION A on top of Sensor Sns22 Caution or Crossing Signal Lights
   AT(24)
    IFTHROWN(0) START(2033)
     ELSE START(2032)
    DONE ENDIF
    
  SEQUENCE(2031)
   AT(25)
    IFTHROWN(0) START(2033)
     ELSE START(2032)
    DONE ENDIF
    
  SEQUENCE(2032)
     PRINT("Crossing Gate Closing")
     CALL(24)               // Set Caution Gate Signals ON Then Return Here
     SERVO2(100, 490, 7000) // Accessory Servo vpin 100 - Counter Clockwise 'Close'
   IF(24)UNLATCH(24)FOLLOW(2033)ENDIF 
    LATCH(24)FOLLOW(2032) DONE
   
   SEQUENCE(2033)
     PRINT("Crossing Gate Opening")
     CALL(25)               // Set Crossing Gate Signals ON Then Return Here
     SERVO2(100, 110, 7000) // Accessory Servo vpin100 Clockwise 'Open'
   IF(25)UNLATCH(25) FOLLOW(2032) ENDIF 
    LATCH(25) FOLLOW(2033) DONE
      
   SEQUENCE(24)
    IFNOT(24)        // Signal Lights as long as Sensor {Sns24} uncovered
     SET(1502)       // DFPlayer MP3 Bell sound ON
      PRINT("Crossing Signals On")
      FADE(115, 0, 0)
      FADE(114, 1000, 0)
      DELAY(750)
      FADE(114, 0, 0)
      FADE(115, 1000, 0)
      DELAY(750)
     IF(22) FOLLOW(2034)DONE ENDIF  // Sensors Sns{24} & {25} Turns them OFf
     IF(23) FOLLOW(2034)DONE ENDIF
    FOLLOW(24)               // Repeat until {Sns25} is Low
     DONE RESET(1500)ENDIF   // IF {Sns25} Then END Sequence (25) Stop DFPlayer
      PRINT("Crossing Gate Up & Signals Off")
      FADE(114,0,0)
      FADE(115,0,0)
    RETURN               // Go back to your script and continue on from your EXRAIL CALL(2030)
     
   SEQUENCE(25)          // Sensor 25 Tripped Signals ON, Else 
     IFNOT(25)           // Signal Lights as long as Sensor {Sns25} uncovered
      SET(1502)          // DFPlayer MP3 Bell sound ON
      PRINT("Crossing Signals On")
      FADE(115, 0, 0)
      FADE(114, 1000, 0)
      DELAY(750)
      FADE(114, 0, 0)
      FADE(115, 1000, 0)
      DELAY(750)
     IF(23) FOLLOW(2034)DONE ENDIF   // Sensors Sns{24} & {25} Turns them OFf
     IF(22) FOLLOW(2034)DONE ENDIF
    FOLLOW(25)               // Repeat until {Sns24} is Low
      DONE RESET(1500)ENDIF  // IF {Sns24} Then END Sequence (24) Stop DFPlayer
      PRINT("Crossing Gate Up & Signals Off")
      FADE(114,0,0)
      FADE(115,0,0)
    RETURN
           
   IF(887) FOLLOW(887) DONE ENDIF
     SEQUENCE(2034)
     SERVO2(100, 110, 6000)         // Open Crossing Gates 'clockwise'
      PRINT("Crossing Gate Up & Signals Off")
      RESET(1500)        // DFPlayer MP3 Bell sound OFF
      FADE(114, 0, 0)    // Turn off Signals 
      FADE(115, 0, 0) 
      PRINT ("FX Crossing Gate Signal OFF")
      PRINT ("Please Press FX Level Gate Crossing {Set} button to Start ")
   START(2030) 
   START(2031)
  ENDTASK
*/

// *********** End of Bonus Lesson 108 Level Crossing Signal & DFPlayer mini MP3 Sound Card*************************** // 
// ******************************************************************************************************************* //

//|||||||||||||| End of EXRAIL Courses LESSONS 106 - 108 Special Device Macros ||||||||||||||||||||||||||||||
//|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

 // ENDEXRAIL   // marks the end of the EXRAIL script Lessons (100)macros for Now.  Can't Wait for more Lessons
   
// |||||||||||||||||||||||||||||||||| End Of myEXRAIL_Courses_100_Macros.h ||||||||||||||||||||||||||||||||||||||||||||||
