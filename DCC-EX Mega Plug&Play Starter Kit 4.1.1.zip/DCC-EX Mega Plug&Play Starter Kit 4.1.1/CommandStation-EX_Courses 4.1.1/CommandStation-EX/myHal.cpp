//  Sample myHal.cpp file.
//   by KC Smith 9-2022
//
// To use this file, copy it to myHal.cpp and uncomment the directives and/or
// edit them to satisfy your requirements.  If you only want to use up to 
// two PCA9685 Servo modules,  or up to two MCP23017 GPIO Expander modules
// then you don't need add more of these to boards at this time, there included for free!

// Note that if the file has a .cpp extension it WILL be compiled into the build
// and the halSetup() function WILL be invoked.
//
// To prevent this, temporarily rename the file to myHal.txt or similar.
//
// The #if directive prevent compile errors for Uno and Nano by excluding the 
//  HAL directives from the build.
// #if !defined(IO_NO_HAL)
//
// Include devices you need.
    #include "IODevice.h"
    #include "IO_HCSR04.h"    // Ultrasonic range sensor for longer distances
 // #include "IO_VL53L0X.h"   // Laser time-of-flight sensor
    #include "IO_DFPlayer.h"  // MP3 Micro-SD card sound player

//==========================================================================
// The function halSetup() is invoked from CS if it exists within the build.
// The setup calls are included between the open and close braces "{ ... }".
// Comments (lines preceded by "//") are optional.
//==========================================================================

void halSetup() {

// =======================================================================
//  Additoinal PCA9685 Servo Signal Board
// =======================================================================
 /*There are soldering points to change the address from 40 to 41, 42 etc
   place drop of solder on A0 and it will add 1 to this boards address.

   Then just chain the two boards together SCL-SCL,  SDA-SDA, VCC-VCC, Gnd-Gnd,
   The command station is setup to automatically recognize the first two PCA boards as address 40 & 41.
   You will then have additional vpin116-132

   Board 0:  Address = 0x40  Offset = binary 00000 (no jumpers required)
   Board 1:  Address = 0x41  Offset = binary 00001 (bridge A0  with a drop of solder)
   Board 2:  Address = 0x42  Offset = binary 00010 (bridge A1) 
   Board 3:  Address = 0x43  Offset = binary 00011 (bridge A0 & A1)
   Board 4:  Address = 0x44  Offset = binary 00100 (bridge A2)
*/
  //=========================================================================
  // The following directive defines a PCA9685 PWM Servo driver module.
  // The First Two PCA9685 Boards 0 & 1 are already configured within the CS 
  //=========================================================================
  // Board 0 parameters are: 
  //  First Vpin=100
  //  Number of VPINs=16 numbered (100-115) I2C address of module=0x40 Default included in CS
  //   PCA9685::create(100, 16, 0x40);  // Default
  // Board 1;
  //  First vpin=116
  //  Number of VPINs=16 numbered (116-131) I2C address of module=0x41 Default included in CS
  //   PCA9685::create(116, 16, 0x41);  // must Solder A0 pad 
  //
  // Board 2 & 3; Must be Added by manually by Uncommenting the PCA9685;;create lines below as needed
  //  Create Two more Servo controller numbered (132-147) & (148-163) on I2C addr 0x42 & Ox43
  //  First vpin=132
  //  Number of VPINs=16 numbered (132-147) I2C address of module=0x42
  //   PCA9685::create(132, 16, 0x42);  // Must Solder A1 and uncomment this line
  //  First vpin=148
  //  Number of VPINs=16 numbered (148-163) I2C address of module=0x43
  //   PCA9685::create(148, 16, 0x43);  // Must Solder A0 & A1 and uncomment this line
  //
  // Note: you will need to solder or bridge the A0-A5 pads as you add more than one board
  // 1st Board 0:  Address = 0x40  Offset = binary 00000 (no jumpers required)
  // 2nd Board 1:  Address = 0x41  Offset = binary 00001 (bridge A0  with a drop of solder)
  // 3rd Board 2:  Address = 0x42  Offset = binary 00010 (bridge A1)
  // 4th Board 3:  Address = 0x43  Offset = binary 00011 (bridge A0 & A1)
  // 5th Board 4:  Address = 0x44  Offset = binary 00100 (bridge A2)

  //=======================================================================
  // The following directive defines an MCP23017 16-port I2C GPIO Extender module.
  //=======================================================================
  // Board 1 parameters are: 
  //  First Vpin=164
  //  Number of VPINs=16 numbered (164-179) I2C address of module=0x20 Default included in CS
  //   MCP23017::create(164, 16, 0x20);
  // Board 2; 
  //  First Vpin=180
  //  Number of VPINs=16 numbered (180-195) I2C address of module=0x21 Default included in CS
  //   MCP23017::create(180, 16, 0x21);
  // Board 3; 
  //  First Vpin=196
  //  Number of VPINs=16 numbered (196-211) I2C address of module=0x22
  //   MCP23017::create(196, 16, 0x22);
  // Board 4;
  //  First Vpin=212
  //  Number of VPINs=16 numbered (212-228) I2C address of module=0x23
  //   MCP23017::create(212, 16, 0x23);
  // etc.

  // Alternative form, which allows the INT pin of the module to request a scan
  // by pulling Arduino pin 40 to ground.  Means that the I2C isn't being polled
  // all the time, only when a change takes place. Multiple modules' INT pins
  // may be connected to the same Arduino pin.
  
  // MCP23017::create(196, 16, 0x22, 40);


  //=======================================================================
  // The following directive defines an MCP23008 8-port I2C GPIO Extender module.
  //=======================================================================
  // The parameters are: 
  //   First Vpin=300
  //   Number of VPINs=8 (numbered 300-307)
  //   I2C address of module=0x22

  //MCP23008::create(300, 8, 0x22);


  //===========================================================================
  // The following directive defines a PCF8574 8-port I2C GPIO Extender module.
  //===========================================================================
  // The parameters are: 
  //   First Vpin=200
  //   Number of VPINs=8 (numbered 200-207)
  //   I2C address of module=0x23

  //PCF8574::create(200, 8, 0x23);


  // Alternative form using INT pin (see above)

  //PCF8574::create(200, 8, 0x23, 40);


  //=======================================================================
  // The following directive defines an HCSR04 ultrasonic ranging module.
  //=======================================================================
  // The parameters are: 
  //   Vpin=2000 (only one VPIN per directive)
  //   Number of VPINs=1
  //   Mega Arduino pin connected from D40=TRIG
  //   Mega Arduino pin connected from D41=ECHO
  //   Minimum trigger range=80cm (VPIN goes to 1 when <80cm)
  //   Maximum trigger range=85cm (VPIN goes to 0 when >85cm)
  // Note: Multiple devices can be configured by using a different ECHO pin for each one.  
  // The TRIG pin can be shared between multiple devices.
  // Be aware that the 'ping' of one device may be received by another device and position them accordingly!
  //                              Cm   Cm
  // example; (id, trigger, echo, min, max)
     HCSR04::create(2000, 40, 41, 80, 85); // 1st Sensor {dpin 40 & 41} set to 80cm to 85cm or 30"-33" detection
  // HCSR04::create(2001, 40, 42, 80, 85); // 2nd Sensor {dpin 40 & 42} set to 80cm to 85cm or 30"-33" detection
                                           // they share {dpin 40} TRIG
// ***************************************************************************************************************** //

  //=======================================================================
  // Play mp3 files from a Micro-SD card, using a DFPlayer MP3 Module.
  //=======================================================================
// DFPlayer::create(1000, 10, Serial1);  
  // Example; create the DFPlayer on vpin1000, 10 files on Mega Tx1 D18, Rx1 D19
  // Parameters: 
  //   1000 = first VPIN allocated.
  //     10 = number of VPINs allocated.
  // Serial1 = name of serial port (usually Serial1 or Serial2).
  // With these parameters, up to 10 files may be played on pins 1000-1009.
  // Play is started from EX-RAIL with SET(1000) for first mp3 file, 
  //  SET(1001) for second file, etc. 
  // Play may also be initiated by writing an analog value to the first pin, e.g. 
  //  SERVO(1000,2,Instant) will play the 2nd mp3 file.
  //  SERVO(1000,2,30) does the same thing, as well as setting the volume to 30 (maximum value).
  // Play is stopped by RESET(1000) (or any other allocated VPIN).
  // Volume may also be set by writing an analogue value to the second pin for the player, e.g.,
  //  SERVO(1001,30,Instant) sets volume of the DFPlayer to maximum (30).
  // The EX-RAIL script may check for completion of play by calling WAITFOR(pin), which will only
  // proceed to the following line when the player is no longer busy.
  // e.g.
  // SEQUENCE(1000) PRINT("DFPlayer Ready")
  //  AT(25)         // At Sensor{Sns25} Tripped Play 1st Sound file
  //   SET(1000)     // Use Any DFPlayer Virtual vpin1000x to trip & Play Sound files
  //   PRINT("DFPlayer 1st Sound") // 1st Sound Automatically played
  //   WAITFOR(1000) // wait for vpin(n) file being played to complete
  //  AT(-25)        // Sensor(Sns25} Released,
  //   SET(1001)     // DFPlayer vpin(1001) 2nd sound file
  //   PRINT("DFPlayer 2nd Sound")
  //   WAITFOR(1001) // wait for vpin(n) file being played to complete
  //  RESET(1000)    // DFPlayer MP3 Sound board Trips OFF
  //   PRINT(" DFPlayer MP3 Sound OFF")
  //  FOLLOW(1000)```   

  // NOTE; To Set the DFPlayer Volume 0-30 from the IDE Serial command line use <D ANOUT 1001 20 Instant> // Set volume to 20
  //       The files on the micro-SD card are numbered from 00 zero to 0xx the number of files on the card i.e. 00-09 for Ten files

  //  Detail Specifications; https://wiki.dfrobot.com/DFPlayer_Mini_SKU_DFR0299

  
  //====================================================================================================
  // The following is an Actual DFPlayer mini Micro-SD MP3 Sound module Definition
  // We'll use it with a HC-SR04 Ultrasonic Sensor to trip sound when you get Too close to the Train Module
  //====================================================================================================

  // Where first Vpin is the first vpin reserved for reading the device,
  //   nPins is the number of pins to be allocated (max 10)
  //   and Serial(n) is the name of the Serial port connected to the DFPlayer (e.g. Serial1).
  //   In setup function within myHal.cpp Uncomment the Serial port you'll use, DO NOT use the same one as WiFI will use
  //   DFPlayer::create(firstVpin, nPins, Serial(n); // Do Not use the same Serial(n) port as your WiFi connection
       DFPlayer::create(1500, 15, Serial1);  // create device 1500, 15 files, on Mega Tx1 Rx1, D18, D19  1K Ohm on D18
  //   DFPlayer::create(1500, 15, Serial2);  // create device 1500, 15 files, on Mega Tx2 Rx2, D16, D17  1K Ohm on D16 
  //   DFPlayer::create(1500, 15, Serial3);  // create device 1500, 15 files, on Mega Tx3 Rx3, D14, D15  1K Ohm on D14
/* Parameters: 
 * Writing an analogue value 0-2999 to the first pin will select a numbered file from the SD card;
 * Writing an analogue value 0-30 to the second pin will set the volume of the output;
 * Writing a digital value to the first pin will play or stop the file;
 * Reading a digital value from any pin will return true(1) if the player is playing, false(0) otherwise.
 * 
 *   1500 = first VPIN allocated.
 *     15 = number of VPINs allocated.
 *  Serial1 = name of serial port (usually Serial1 or Serial2).
 *  With these parameters, up to 15 files may be played on pins 1500-1514
 *  Play is started from EX-RAIL with SET(1500) for first mp3 file, 
 *  SET(1501) for second file, etc.  
 *  Play may also be initiated by writing an analogue value to the first pin, e.g. 
 *  SERVO(1500,2,Instant) will play the 2nd mp3 file.
 *  SERVO(1500,2,30)does the same thing, as well as setting the volume to 30 (maximum value).
 *  Play is stopped by RESET(1500) (or any other allocated VPIN).
 *  Volume may also be set by writing an analogue value to the second pin for the player, e.g. 
 *  SERVO(1501,30,Instant) sets volume of DFPlayer to maximum (30).
 *  The EX-RAIL script may check for completion of play by calling WAITFOR(pin), which will only 
 *  proceed to the following line when the player is no longer busy.
  
// NOTE; To Set the DFPlayer Volume 0-30 from the IDE Serial command line use <D ANOUT 1501 20 Instant> // Set volume to 20

// Actual DFPlayer used with a EXRAIL ROUTE(885, "Ultrasonic Sensor On/Off") SEQUENCE(2020) example
 * SEQUENCE(2020)PRINT("FX UltraSonic Sensor Ready")
 *  AT(2000)                        // At Sensor{Sns25} Tripped Play 1st Sound file
 *   SET(1500)                      // Virtual pin1500 to trip the DFPlayer MP3 On & Plays 1st Sound file
 *    PRINT ("PLEASE Step Back From The Module!!")
 *   WAITFOR(1500)                  // wait for vpin file currently being played to complete
 *  AT(-2000)                       // Ultrasonic Sensor(Sns2000} Released, They Stepped Back Away from the Module.  
 *   SET(1501)                      // Plays the 2nd sound file
 *    PRINT("We Thank You! Msg..")  // Message Played
 *   RESET(1500)                    // DFPlayer MP3 Sound board Trips OFF
 *    PRINT("DFPlayer MP3 Sound OFF")
 *   FOLLOW(2020)
 *   
 * NB The DFPlayer's serial lines are not 5V safe, so connecting the Arduino TX directly 
 * to the DFPlayer's RX terminal will cause lots of noise over the speaker, or worse.
 * A 1k ohm resistor in series with the module's RX terminal to the Mega TX pin will alleviate this.
 */
 }
