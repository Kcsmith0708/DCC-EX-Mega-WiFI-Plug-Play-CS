There are 14 different sample mp3 sounds in the file folder.
You must copy them One at a Time in the order you want them to Play.

In the myEXRAI_Courses_100_Macros.f file at about script line  890
You will see a list of sound files with all but one commented out.
The Uncomment line will be the line that plays when the 
Engine Driver "FX DFPlayer Sound X file" {Set} button is pressed.
Or you can Start Any sound from the Serial Monitor with <Z 150x 1>
and Stop the same sound with <Z 150x 0>.  the x is the sound file id number below.

// Bonus FX DFPlayer # Sound commands that play Individuale Audio sounds directly
// Uncomment the commands you wish to use from a WiFi Throttle
 ROUTE(1550,"FX DFPlayer # Sound")// a Engine Driver{Set} & WiThrottle{Route} button
  PRINT("Play DFPlayer file# ON")   // OR Start & Stop it with </START 1550> command Or a Direct pin with <Z 1500n 1>
// PARSE("<Z 1500 1>")  // Play  1st sound  Please Step Back
// PARSE("<Z 1501 1>")  // Play  2nd sound  We Thank You
// PARSE("<Z 1502 1>")  // Play  3rd sound  X-Bell
// PARSE("<Z 1503 1>")  // Play  4th sound  Arc Welder 
// PARSE("<Z 1504 1>")  // Play  5th sound  Can you Fill The Tank?
// PARSE("<Z 1505 1>")  // Play  6th sound  Water Filling Tank
// PARSE("<Z 1506 1>")  // Play  7th sound  Campfire
   PARSE("<Z 1507 1>")  // Play  8th sound  All Aboard
// PARSE("<Z 1508 1>")  // Play  9th sound  Arriving Track A
// PARSE("<Z 1509 1>")  // Play 10th sound  Arriving Track B
// PARSE("<Z 1510 1>")  // Play 11th sound  Big Ben Chime
// PARSE("<Z 1511 1>")  // Play 12th sound  Polar Express You Coming?
// PARSE("<Z 1512 1>")  // Play 13th sound  3M Full of Moonshine, FBI on the Way
// PARSE("<Z 1513 1>")  // Play 14th sound  DCC-EX Play Time Over, High Tail it Back
// PARSE("<Z 1514 1>")  // Play 15th sound  Decide what to do? Automation or Manual
   WAITFOR(1507)        // Change this # to Match the number of your uncommented 1500#
  PRINT("Play DFPlayer file# OFF") 
  ENDTASK

// 3M is 'Michigan Midnight Moonshine' 3M Railroad at the Waterfall Tower taking 3M Moonshine Orders
